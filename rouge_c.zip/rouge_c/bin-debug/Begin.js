var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Begin = (function (_super) {
    __extends(Begin, _super);
    function Begin(_itemData, mainsence) {
        var _this = _super.call(this) || this;
        _this.goodsItemData = _itemData;
        _this.m_mainsence = mainsence;
        _this.skinName = "resource/skin/begin.exml";
        return _this;
    }
    Begin.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.gp_bottom.y = this.stage.stageHeight - this.gp_bottom.height;
        console.log("this.gp_bottom.y" + this.gp_bottom.y + "^^^^" + this.stage.stageHeight);
        if (this.goodsItemData.gameType == Data.GameType.TI_YAN) {
            // console.log("免费的" + this._freeType)
            this.gp_paihang.visible = false;
            this.lb_tishi.visible = true;
        }
        else if (this.goodsItemData.gameType == Data.GameType.JING_SU ||
            this.goodsItemData.gameType == Data.GameType.CHUANG_GUAN) {
            this.gp_paihang.visible = true;
            this.lb_tishi.visible = false;
        }
        else {
            console.log("付费区");
            this.onClickBegin();
        }
        // if (this.goodsItemData.gameType == Data.GameType.TI_YAN) {
        //     this.gp_paihang.visible = false;
        //     this.lb_tishi.visible = true;
        // }
        this.init();
        this.btn_share.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickShare, this);
        this.btn_begin.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBegin, this);
        this.btn_back.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBack, this);
    };
    Begin.prototype.init = function () {
        var context = this;
        for (var i = 0; i < 10; i++) {
            var item = new Paihang_items(i);
            context.gp_paihang.addChild(item);
            item.y = item.height * i + 5 * i;
        }
    };
    //分享
    Begin.prototype.onClickShare = function () {
    };
    //开始游戏
    Begin.prototype.onClickBegin = function () {
        if ((Data.GameContext.player.goldNumber - this.goodsItemData.goodsFenqu) >= 0) {
            RougeGameApi.startGame(this.goodsItemData.subGameId, this.goodsItemData.goodsType, this.goodsItemData.goodsFenqu, this.goodsItemData.gameType, 0);
            console.log("*******Send   ed ");
            // AccountData.accoundData.gold -= this.goodsItemData.goodsFenqu;
            console.log("AccountData.accoundData.gold   :" + Data.GameContext.player.goldNumber);
            var gameMain = new GameMain(this.goodsItemData, this.m_mainsence);
            this.stage.addChild(gameMain);
        }
        else {
            // this.addChild(new Tishi(this.m_mainsence));
            this.addChild(new Tishi2());
        }
    };
    Begin.prototype.onClickBack = function () {
        this.visible = false;
        this.m_mainsence.visible = true;
    };
    return Begin;
}(eui.Component));
__reflect(Begin.prototype, "Begin");
//# sourceMappingURL=Begin.js.map