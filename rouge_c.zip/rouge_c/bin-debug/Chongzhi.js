var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Chongzhi = (function (_super) {
    __extends(Chongzhi, _super);
    function Chongzhi(mainsence) {
        var _this = _super.call(this) || this;
        _this._mainsence = mainsence;
        _this.skinName = "resource/skin/chongzhi.exml";
        return _this;
    }
    Chongzhi.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.rect_back.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickBack, this);
        this.chongzhi1.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz1, this);
        this.chongzhi2.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz2, this);
        this.chongzhi3.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz3, this);
        this.chongzhi4.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz4, this);
        this.chongzhi5.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz5, this);
        this.chongzhi6.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz6, this);
    };
    Chongzhi.prototype.init = function () {
    };
    Chongzhi.prototype.onclickBack = function () {
        PlayerApi.getPlayerInfo();
        this.visible = false;
        // this.parent.removeChild(this);  
    };
    Chongzhi.prototype.onclickCz1 = function () {
        // 通知服务器下单；
        OrderApi.createOrder("钻石充值", 6);
    };
    Chongzhi.prototype.onclickCz2 = function () {
        // 通知服务器下单；
        OrderApi.createOrder("钻石充值", 12);
    };
    Chongzhi.prototype.onclickCz3 = function () {
        // 通知服务器下单；
        OrderApi.createOrder("钻石充值", 15);
    };
    Chongzhi.prototype.onclickCz4 = function () {
        // 通知服务器下单；
        OrderApi.createOrder("钻石充值", 20);
    };
    Chongzhi.prototype.onclickCz5 = function () {
        // 通知服务器下单；
        OrderApi.createOrder("钻石充值", 50);
    };
    Chongzhi.prototype.onclickCz6 = function () {
        // 通知服务器下单；
        OrderApi.createOrder("钻石充值", 100);
    };
    return Chongzhi;
}(eui.Component));
__reflect(Chongzhi.prototype, "Chongzhi");
//# sourceMappingURL=Chongzhi.js.map