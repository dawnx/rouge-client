var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Data;
(function (Data) {
    var DataManager = (function () {
        function DataManager() {
        }
        DataManager.init = function () {
            DataManager.goodsDatas = [
                new Data.GoodsItemData(1001, "resource/assets/chongzhi/kouhong1.png", "体验模式无任何收益", Data.GameType.TI_YAN, "￥:0", Data.GoodsType.KOU_HONG, 0),
                new Data.GoodsItemData(1002, "resource/assets/chongzhi/kouhong2.png", "迪奥999系列", Data.GameType.CHUANG_GUAN, "￥:300", Data.GoodsType.KOU_HONG, 0),
                new Data.GoodsItemData(1003, "resource/assets/chongzhi/kouhong2.png", "迪奥999系列", Data.GameType.JING_SU, "￥:300", Data.GoodsType.KOU_HONG, 0),
                new Data.GoodsItemData(1004, "resource/assets/chongzhi/kouhong3.png", "美宝莲星钻小灯管唇膏口红", Data.GameType.CHUANG_GUAN, "￥:128", Data.GoodsType.KOU_HONG, 100),
                new Data.GoodsItemData(1005, "resource/assets/chongzhi/kouhong2.png", "迪奥999系列", Data.GameType.CHUANG_GUAN, "￥:300", Data.GoodsType.KOU_HONG, 300),
                new Data.GoodsItemData(2001, "resource/assets/chongzhi/lipin1.png", "大象保温不倒杯", Data.GameType.CHUANG_GUAN, "￥:199", Data.GoodsType.LI_PIN, 100),
                new Data.GoodsItemData(2002, "resource/assets/chongzhi/lipin2.png", "化妆镜", Data.GameType.CHUANG_GUAN, "￥:199", Data.GoodsType.LI_PIN, 100),
                new Data.GoodsItemData(2003, "resource/assets/chongzhi/lipin3.png", "手持挂烫机", Data.GameType.CHUANG_GUAN, "￥:300", Data.GoodsType.LI_PIN, 300),
                new Data.GoodsItemData(2004, "resource/assets/chongzhi/lipin4.png", "腾讯授权蓝牙耳机", Data.GameType.CHUANG_GUAN, "￥:500", Data.GoodsType.LI_PIN, 500),
                new Data.GoodsItemData(3001, "resource/assets/chongzhi/pifu1.png", "588皮肤系列", Data.GameType.CHUANG_GUAN, "￥:58.80", Data.GoodsType.PI_FU, 100),
                new Data.GoodsItemData(3002, "resource/assets/chongzhi/pifu2.png", "788皮肤系列", Data.GameType.CHUANG_GUAN, "￥:78.80", Data.GoodsType.PI_FU, 100),
                new Data.GoodsItemData(3003, "resource/assets/chongzhi/pifu3.png", "888皮肤系列", Data.GameType.CHUANG_GUAN, "￥:88.80", Data.GoodsType.PI_FU, 100),
                new Data.GoodsItemData(3004, "resource/assets/chongzhi/pifu4.png", "1188皮肤系列", Data.GameType.CHUANG_GUAN, "￥:118.80", Data.GoodsType.PI_FU, 300),
                new Data.GoodsItemData(3005, "resource/assets/chongzhi/pifu5.png", "1688皮肤系列", Data.GameType.CHUANG_GUAN, "￥:168.80", Data.GoodsType.PI_FU, 300),
                new Data.GoodsItemData(3006, "resource/assets/chongzhi/pifu6.png", "2888皮肤系列", Data.GameType.CHUANG_GUAN, "￥:288.80", Data.GoodsType.PI_FU, 300),
                new Data.GoodsItemData(3007, "resource/assets/chongzhi/pifu7.png", "王者水晶", Data.GameType.CHUANG_GUAN, "￥:500", Data.GoodsType.PI_FU, 500),
            ];
        };
        return DataManager;
    }());
    Data.DataManager = DataManager;
    __reflect(DataManager.prototype, "Data.DataManager");
})(Data || (Data = {}));
//# sourceMappingURL=DataManager.js.map