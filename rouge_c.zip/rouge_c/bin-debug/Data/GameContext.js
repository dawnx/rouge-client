var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Data;
(function (Data) {
    var GameContext = (function () {
        function GameContext() {
        }
        return GameContext;
    }());
    Data.GameContext = GameContext;
    __reflect(GameContext.prototype, "Data.GameContext");
})(Data || (Data = {}));
//# sourceMappingURL=GameContext.js.map