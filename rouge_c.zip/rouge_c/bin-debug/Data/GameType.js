var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Data;
(function (Data) {
    var GameType = (function () {
        function GameType() {
        }
        //public gameType: number; // 1 体验 ，2 闯关，  3 竞速
        GameType.TI_YAN = 1;
        GameType.CHUANG_GUAN = 2;
        GameType.JING_SU = 3;
        return GameType;
    }());
    Data.GameType = GameType;
    __reflect(GameType.prototype, "Data.GameType");
})(Data || (Data = {}));
//# sourceMappingURL=GameType.js.map