var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Data;
(function (Data) {
    var GoodsItemData = (function () {
        function GoodsItemData(m_subGameId, _img, _goodsName, _gameType, _price, _goodsType, _goodsFenqu) {
            this.subGameId = m_subGameId;
            this.img = _img;
            this.goodsName = _goodsName;
            this.gameType = _gameType;
            this.price = _price;
            this.goodsType = _goodsType;
            this.goodsFenqu = _goodsFenqu;
        }
        return GoodsItemData;
    }());
    Data.GoodsItemData = GoodsItemData;
    __reflect(GoodsItemData.prototype, "Data.GoodsItemData");
})(Data || (Data = {}));
//# sourceMappingURL=GoodsItemData.js.map