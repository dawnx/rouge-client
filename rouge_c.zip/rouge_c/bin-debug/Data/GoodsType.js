var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Data;
(function (Data) {
    var GoodsType = (function () {
        function GoodsType() {
        }
        //1口红，2礼品，3皮肤
        GoodsType.KOU_HONG = 1;
        GoodsType.LI_PIN = 2;
        GoodsType.PI_FU = 3;
        return GoodsType;
    }());
    Data.GoodsType = GoodsType;
    __reflect(GoodsType.prototype, "Data.GoodsType");
})(Data || (Data = {}));
//# sourceMappingURL=GoodsType.js.map