var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Data;
(function (Data) {
    var PlayerData = (function () {
        function PlayerData() {
        }
        return PlayerData;
    }());
    Data.PlayerData = PlayerData;
    __reflect(PlayerData.prototype, "Data.PlayerData");
})(Data || (Data = {}));
//# sourceMappingURL=PlayerData.js.map