var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
// TypeScript file
var Data;
(function (Data) {
    var RankData = (function () {
        function RankData() {
        }
        return RankData;
    }());
    Data.RankData = RankData;
    __reflect(RankData.prototype, "Data.RankData");
})(Data || (Data = {}));
//# sourceMappingURL=RankData.js.map