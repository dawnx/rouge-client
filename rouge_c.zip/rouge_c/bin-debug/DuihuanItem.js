var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var DuihuanItem = (function (_super) {
    __extends(DuihuanItem, _super);
    function DuihuanItem(mainsence, edu) {
        var _this = _super.call(this) || this;
        // private onclickClose() {
        //     // this.parent.removeChild(this);
        //     AccountData.GetInfo();
        //     this._mainsence.RefeshAccountData();
        //     this._mainsence.chongzhi.visible = false;
        _this.isExchange = false;
        _this._mainsence = mainsence;
        _this._edu = edu;
        _this.skinName = "resource/skin/duihuanitem.exml";
        return _this;
    }
    DuihuanItem.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        // this.img_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickClose, this);
        this.btnQueding.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickQueding, this);
    };
    DuihuanItem.prototype.init = function () {
        this.edu.text = "此次兑换额度为：" + this._edu;
    };
    // }
    //兑换
    DuihuanItem.prototype.onclickQueding = function () {
        console.log("ASDASD@#@!#" + this._edu);
        OrderApi.purchase(ItemDefine.Gold, this._edu / 3);
        // this.parent.removeChild(this);
        console.log("dianjiOK     !!!!");
        if ((Data.GameContext.player.diamond - this._edu / 3) >= 0) {
            // AccountData.accoundData.diamond -= this._edu / 3;
            this.isExchange = true;
        }
        else {
            this.addChild(new Tishi1(this._mainsence));
        }
        if (this.isExchange) {
            Data.GameContext.player.goldNumber += this._edu;
            this.isExchange = false;
        }
        this.parent.removeChild(this);
        console.log(this.parent);
        // this._mainsence.duihuan.visible = false;
    };
    return DuihuanItem;
}(eui.Component));
__reflect(DuihuanItem.prototype, "DuihuanItem");
//# sourceMappingURL=DuihuanItem.js.map