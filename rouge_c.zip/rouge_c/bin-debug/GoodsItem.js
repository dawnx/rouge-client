var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var GoodsItem = (function (_super) {
    __extends(GoodsItem, _super);
    function GoodsItem(_itemData, mainsence) {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skin/goodsItem.exml";
        _this.itemData = _itemData;
        _this.m_mainsence = mainsence;
        return _this;
    }
    GoodsItem.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickBtn, this);
    };
    GoodsItem.prototype.init = function () {
        this.goodsImg.source = this.itemData.img;
        this.goodsName.text = this.itemData.goodsName;
        if (this.itemData.gameType == 1)
            this.btnText.text = "体验";
        else if (this.itemData.gameType == 2)
            this.btnText.text = "闯关";
        else if (this.itemData.gameType == 3)
            this.btnText.text = "竞速";
        this.price.text = this.itemData.price;
    };
    GoodsItem.prototype.onClickBtn = function () {
        var currentGolds = Data.GameContext.player.goldNumber;
        if (this.itemData.goodsFenqu == 0) {
            PlayerApi.getRankInfo(this.itemData.subGameId);
            this.stage.addChild(new Begin(this.itemData, this.m_mainsence));
        }
        else if (currentGolds >= this.itemData.goodsFenqu) {
            RougeGameApi.startGame(this.itemData.subGameId, this.itemData.goodsType, this.itemData.goodsFenqu, this.itemData.gameType, 0);
            console.log("*******Send   ed ");
            var gameMain = new GameMain(this.itemData, this.m_mainsence);
            this.stage.addChild(gameMain);
        }
        else {
            this.stage.addChild(new Tishi(this.m_mainsence));
        }
        if (this.itemData.goodsType == 2 || this.itemData.goodsType == 3) {
        }
    };
    return GoodsItem;
}(eui.Component));
__reflect(GoodsItem.prototype, "GoodsItem");
//# sourceMappingURL=GoodsItem.js.map