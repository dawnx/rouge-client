var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LoadingUI = (function (_super) {
    __extends(LoadingUI, _super);
    function LoadingUI() {
        var _this = _super.call(this) || this;
        _this.res_loadingBg = "resource/assets/loading/bg.png";
        _this.res_loadingBg1 = "resource/assets/loading/logo.png";
        _this.res_loadingBg2 = "resource/assets/loading/main_img.png";
        _this.res_loadingBg3 = "resource/assets/loading/lodImg.png";
        _this.loadW = 750;
        _this.devDown = 150;
        _this.createView();
        return _this;
    }
    LoadingUI.prototype.createView = function () {
        this.w = Main._screenW;
        this.h = Main._screenH;
        console.log(this.w + "^^" + this.h);
        //大背景
        var imgBgLoader = new egret.ImageLoader;
        imgBgLoader.once(egret.Event.COMPLETE, this.imgLoadBgHandler, this);
        imgBgLoader.load(this.res_loadingBg);
        //赤兔LOGO
        var imgLoading0Loader = new egret.ImageLoader;
        imgLoading0Loader.once(egret.Event.COMPLETE, this.imgLoad0Handler, this);
        imgLoading0Loader.load(this.res_loadingBg1);
        //喵喵图片
        var imgLoading1Loader = new egret.ImageLoader;
        imgLoading1Loader.once(egret.Event.COMPLETE, this.imgLoad1Handler, this);
        imgLoading1Loader.load(this.res_loadingBg2);
        //圆圈  点点点图片
        var imgLoading2Loader = new egret.ImageLoader;
        imgLoading2Loader.once(egret.Event.COMPLETE, this.imgLoad2Handler, this);
        imgLoading2Loader.load(this.res_loadingBg3);
        this.img_loadingBg = new egret.Bitmap();
        this.img_loadingBg1 = new egret.Bitmap();
        this.img_loadingBg2 = new egret.Bitmap();
        this.img_loadingBg3 = new egret.Bitmap();
        this.addChildAt(this.img_loadingBg, 0);
        this.addChildAt(this.img_loadingBg1, 1);
        this.addChildAt(this.img_loadingBg2, 1);
        this.addChildAt(this.img_loadingBg3, 1);
        this.textField = new egret.TextField();
        this.textField.textColor = 0xffffff;
        this.textField.size = 20;
        this.textField.width = this.w;
        this.textField.height = 100;
        this.textField.y = this.h / 2 + 200;
        this.textField.textAlign = egret.HorizontalAlign.CENTER;
        this.textField.verticalAlign = egret.VerticalAlign.MIDDLE;
        console.log(this.textField.x + "%%%" + this.textField.y);
        this.addChildAt(this.textField, 3);
        this.textField2 = new egret.TextField();
        this.textField2.textColor = 0xffffff;
        this.textField2.size = 20;
        this.textField2.width = this.w;
        this.textField2.height = 100;
        this.textField2.y = this.h / 2 + 300;
        this.textField2.textAlign = egret.HorizontalAlign.CENTER;
        this.textField2.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.addChildAt(this.textField2, 3);
        // 监听帧事件,每帧都让loading图片转动
        this.addEventListener(egret.Event.ENTER_FRAME, this.updata, this);
    };
    LoadingUI.prototype.updata = function () {
        // 旋转
        this.img_loadingBg3.rotation += 5;
    };
    LoadingUI.prototype.imgLoadBgHandler = function (evt) {
        this.img_loadingBg.texture = this.getTexture(evt);
        this.img_loadingBg.width = Main._screenW;
        this.img_loadingBg.height = Main._screenH;
        // this.img_loadingBg.y = this.stage.stageHeight - this.img_loadingBg.height;
    };
    LoadingUI.prototype.imgLoad0Handler = function (evt) {
        this.img_loadingBg1.texture = this.getTexture(evt);
        this.img_loadingBg1.scaleX = 0.7;
        this.img_loadingBg1.scaleY = 0.7;
        this.img_loadingBg1.x = 30;
        this.img_loadingBg1.y = 30;
    };
    LoadingUI.prototype.imgLoad1Handler = function (evt) {
        this.img_loadingBg2.texture = this.getTexture(evt);
        // this.img_loadingBg2.scale9Grid = new egret.Rectangle(5, 5, 10, 10);
        // this.img_loadingBg2.width = 121;
        this.img_loadingBg2.x = this.w / 2 - this.img_loadingBg2.width / 2;
        this.img_loadingBg2.y = this.h / 7;
    };
    LoadingUI.prototype.imgLoad2Handler = function (evt) {
        this.img_loadingBg3.texture = this.getTexture(evt);
        this.img_loadingBg3.anchorOffsetX = this.img_loadingBg3.width / 2;
        this.img_loadingBg3.anchorOffsetY = this.img_loadingBg3.height / 2;
        this.img_loadingBg3.x = this.w / 2;
        this.img_loadingBg3.y = this.h / 2;
        console.log(this.img_loadingBg3.x + "#@!#!@+" + this.w + "图片大小" + this.img_loadingBg3.width);
    };
    LoadingUI.prototype.getTexture = function (evt) {
        var loader = evt.target;
        var bitmapData = loader.data;
        var texture = new egret.Texture();
        texture.bitmapData = bitmapData;
        return texture;
    };
    LoadingUI.prototype.onProgress = function (current, total) {
        this.textField.text = "\u793C\u76D2\u6B63\u5728\u642C\u8FD0\u4E2D";
        this.textField2.text = "\u9996\u6B21\u6CE8\u518C\u4E14\u5206\u4EAB\u7684\u7528\u6237\u53EF\u4EE5\u83B7\u5F97\u65B0\u4EBA\u793C\u76D2";
        // if (this.img_loading1 != null) {
        //     this.img_loading1.width = this.loadW * (current / total);
        // }
    };
    return LoadingUI;
}(egret.Sprite));
__reflect(LoadingUI.prototype, "LoadingUI", ["RES.PromiseTaskReporter"]);
//# sourceMappingURL=LoadingUI.js.map