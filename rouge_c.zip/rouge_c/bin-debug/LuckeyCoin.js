var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LuckeyCoin = (function (_super) {
    __extends(LuckeyCoin, _super);
    function LuckeyCoin() {
        var _this = _super.call(this) || this;
        _this.skinName = "resource/skin/luckeycoin.exml";
        return _this;
    }
    LuckeyCoin.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.img_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickClose, this);
        // this.btnQueding.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickQueding, this);
    };
    LuckeyCoin.prototype.init = function () {
    };
    //前往充值
    // private onclickQueding() {
    //     // this.parent.removeChild(this);
    //     this.stage.addChild(new Chongzhi());
    // }
    LuckeyCoin.prototype.onclickClose = function () {
        this.parent.removeChild(this);
    };
    return LuckeyCoin;
}(eui.Component));
__reflect(LuckeyCoin.prototype, "LuckeyCoin");
//# sourceMappingURL=LuckeyCoin.js.map