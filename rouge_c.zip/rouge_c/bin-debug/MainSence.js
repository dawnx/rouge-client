var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var MainSence = (function (_super) {
    __extends(MainSence, _super);
    function MainSence() {
        var _this = _super.call(this) || this;
        _this.index = 1;
        _this.skinName = "resource/skin/mainsence.exml";
        return _this;
    }
    MainSence.prototype.childrenCreated = function () {
        var _this = this;
        _super.prototype.childrenCreated.call(this);
        this.BG.width = Main._screenW;
        this.BG.height = Main._screenH;
        //跑马灯
        this.paomaText.x = 750;
        egret.Tween.get(this.paomaText, { loop: true }).to({ x: -this.paomaText.width }, 9000)
            .call(function () {
            _this.paomaText.x = 750;
        });
        //进入页面默认选免费模式 默认礼品为口红
        this.init();
        this.goodsFenQu = 0;
        console.log(this.goodsFenQu);
        //this.type = 1;
        this.goodsType = Data.GoodsType.KOU_HONG; //口红
        console.log("金币区:" + this.goodsFenQu + "%%" + "礼品方式：" + this.goodsType);
        this.updateContent();
        //充值
        this.img_chongzhi.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickChongzhi, this);
        this.img_duihuan.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickDuihuan, this);
        //轮播图
        this.rad1.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickRad1, this);
        this.rad2.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickRad2, this);
        this.img_bg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickImg_bg, this);
        // 奖励方式
        this.rect_kh.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickGoodsType, this);
        this.rect_lp.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickGoodsType, this);
        this.rect_pf.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickGoodsType, this);
        //付费还是免费
        this.rect0.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickFreeType, this);
        this.rect100.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickFreeType, this);
        this.rect300.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickFreeType, this);
        this.rect500.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickFreeType, this);
        //点击幸运币 弹出规则
        this.luckCoin.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickLuckCoin, this);
        // 事件系统
        EventManager.getInstance().addEventListener(ApiEvent.PLAYER_INFO, this.onPlayerInfo, this);
    };
    MainSence.prototype.init = function () {
        // 返回到主界面的时候，调取用户信息，继续执行 刷新；
        PlayerApi.getPlayerInfo();
        // // 兑换接口；
        // NetSend.SendToNetExchange(Item.Gold, 1);
        // console.log("兑换  金币   1  个");
        //  刷新用户信息，调动此方法时必选先拉取用户信息，才能保证正确刷新；
        this.onPlayerInfo();
        console.log("刷新用户信息；");
        this.Clcik();
        this.lb_kh.textColor = 0x9e023e;
        this.lb_0.textColor = 0xef0057;
        //刚进来的时候 默认是口红，所以让500金币区消失
        this.gp500.width = 0;
        this.gp500.visible = false;
        var timer = new egret.Timer(3000, 0);
        timer.addEventListener(egret.TimerEvent.TIMER, this.timerFunc, this);
        timer.start();
    };
    MainSence.prototype.onPlayerInfo = function () {
        console.log("RefeshAccountData    !");
        var account = Data.GameContext.player;
        if (account != null) {
            console.log("accountData   " + account);
            this.lb_gold.text = account.diamond.toString();
            this.lb_gold0.text = account.goldNumber.toString();
            this.lb_gold1.text = account.luckyCoin.toString();
        }
        else {
            console.log("Error : Account is not Exit!");
        }
        // console.log("AccountData.accoundData.gold   :" + account.goldNumber);
    };
    MainSence.prototype.timerFunc = function () {
        // console.log(this.index)
        this.Clcik();
        this.index++;
        if (this.index > 2) {
            this.index = 1;
        }
    };
    MainSence.prototype.onClickChongzhi = function () {
        // this.addChild(new Chongzhi());
        if (this.chongzhi == null) {
            this.chongzhi = new Chongzhi(this);
            this.addChild(this.chongzhi);
            console.log("无");
        }
        else {
            this.chongzhi.visible = true;
            console.log("有");
        }
    };
    MainSence.prototype.onClickDuihuan = function () {
        this.addChild(new Duihuan(this));
        if (this.duihuan == null) {
            this.duihuan = new Duihuan(this);
            this.addChild(this.duihuan);
        }
        else {
            this.duihuan.visible = true;
        }
    };
    MainSence.prototype.onClickLuckCoin = function () {
        this.addChild(new LuckeyCoin());
    };
    MainSence.prototype.onClickRad1 = function () {
        this.index = 1;
        this.Clcik();
    };
    MainSence.prototype.onClickRad2 = function () {
        this.index = 2;
        this.Clcik();
    };
    MainSence.prototype.onClickImg_bg = function () {
        if (this.index == 1) {
            console.log("第一个");
            this.addChild(new ShouChong(this));
        }
        else if (this.index == 2) {
            console.log("第二个");
            this.addChild(new YaoQing());
        }
    };
    MainSence.prototype.onClickFreeType = function (e) {
        utils.SoundUtils.instance().playAnniu();
        var img = e.target;
        this.lb_0.textColor = 0x333333;
        this.lb_100.textColor = 0x333333;
        this.lb_300.textColor = 0x333333;
        this.lb_500.textColor = 0x333333;
        switch (img.name) {
            //免费区
            case "rect0":
                this.goodsFenQu = 0;
                this.lb_0.textColor = 0x9e023e;
                break;
            //100
            case "rect100":
                this.goodsFenQu = 100;
                this.lb_100.textColor = 0x9e023e;
                break;
            //300
            case "rect300":
                this.goodsFenQu = 300;
                this.lb_300.textColor = 0x9e023e;
                break;
            //500
            case "rect500":
                this.goodsFenQu = 500;
                this.lb_500.textColor = 0x9e023e;
                break;
        }
        console.log(this.goodsFenQu);
        this.updateContent();
    };
    MainSence.prototype.onClickGoodsType = function (e) {
        utils.SoundUtils.instance().playAnniu();
        var img = e.target;
        this.lb_kh.textColor = 0xffffff;
        this.lb_lp.textColor = 0xffffff;
        this.lb_pf.textColor = 0xffffff;
        switch (img.name) {
            //口红
            case "rect_kh":
                //商品类型不是口红的时候 
                if (this.goodsType != Data.GoodsType.KOU_HONG) {
                    this.goodsFenQu = 0;
                }
                this.lb_kh.textColor = 0x9e023e;
                this.goodsType = Data.GoodsType.KOU_HONG; //1口红
                //如果点的是口红，就让免费区 宽度还原.visible为true
                this.gp0.width = 187.5;
                this.gp0.visible = true;
                //如果点的时候口红，让500金币区消失
                this.gp500.width = 0;
                this.gp500.visible = false;
                this.lb_0.textColor = 0x9e023e;
                this.lb_100.textColor = 0x333333;
                break;
            //礼品
            case "rect_lp":
                if (this.goodsType != Data.GoodsType.LI_PIN) {
                    this.goodsFenQu = 100;
                }
                //如果点的是礼品和皮肤，就让免费区 宽度=0.visible为false
                this.gp0.width = 0;
                this.gp0.visible = false;
                //如果点的不是口红，让500金币区出现
                this.gp500.width = 187.5;
                this.gp500.visible = true;
                this.goodsType = Data.GoodsType.LI_PIN;
                this.lb_lp.textColor = 0x9e023e;
                this.lb_100.textColor = 0x9e023e;
                this.lb_300.textColor = 0x333333;
                this.lb_500.textColor = 0x333333;
                break;
            //皮肤
            case "rect_pf":
                if (this.goodsType != Data.GoodsType.PI_FU) {
                    this.goodsFenQu = 100;
                }
                //如果点的是礼品和皮肤，就让免费区 宽度=0.visible为false
                this.gp0.width = 0;
                this.gp0.visible = false;
                //如果点的不是口红，让500金币区出现
                this.gp500.width = 187.5;
                this.gp500.visible = true;
                this.goodsType = Data.GoodsType.PI_FU;
                this.lb_pf.textColor = 0x9e023e;
                this.lb_100.textColor = 0x9e023e;
                this.lb_300.textColor = 0x333333;
                this.lb_500.textColor = 0x333333;
                break;
        }
        console.log(this.goodsType);
        this.updateContent();
    };
    MainSence.prototype.updateContent = function () {
        var _this = this;
        this.gp_main.removeChildren();
        Data.DataManager.goodsDatas.forEach(function (item) {
            if (item.goodsType == _this.goodsType && item.goodsFenqu == _this.goodsFenQu) {
                _this.gp_main.addChild(new GoodsItem(item, _this));
            }
        });
    };
    MainSence.prototype.Clcik = function () {
        if (this.index == 1) {
            this.img_bg.source = "resource/assets/dating/lunbo_2.png";
            this.rad1.selected = true;
            this.rad2.selected = false;
        }
        else if (this.index == 2) {
            this.img_bg.source = "resource/assets/dating/lunbo_1.png";
            this.rad2.selected = true;
            this.rad1.selected = false;
        }
    };
    return MainSence;
}(eui.Component));
__reflect(MainSence.prototype, "MainSence");
//# sourceMappingURL=MainSence.js.map