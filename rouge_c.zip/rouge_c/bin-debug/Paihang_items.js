var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Paihang_items = (function (_super) {
    __extends(Paihang_items, _super);
    function Paihang_items(index) {
        var _this = _super.call(this) || this;
        _this.images = [
            "resource/assets/chongzhi/kouhong2.png",
            "resource/assets/chongzhi/zidan.png",
            "resource/assets/chongzhi/zidan.png",
            "resource/assets/chongzhi/kouhong3.png",
            "resource/assets/chongzhi/kouhong3.png",
            "resource/assets/chongzhi/kouhong3.png",
            "resource/assets/chongzhi/kapai.png",
            "resource/assets/chongzhi/kapai.png",
            "resource/assets/chongzhi/kapai.png",
            "resource/assets/chongzhi/kapai.png",
        ];
        _this.rankData = [];
        _this._index = index;
        _this.skinName = "resource/skin/paihang_items.exml";
        return _this;
    }
    Paihang_items.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
    };
    Paihang_items.prototype.init = function () {
        // this.img_jiangpin.source = this.images[this._index];
        // this.m_icon.source = Data.GameContext.rankDataArray[this._index].headPic;
        // this.m_nick = Data.GameContext.rankDataArray[this._index].nick;
        // this.m_grade = Data.GameContext.rankDataArray[this._index].score.toString();
    };
    return Paihang_items;
}(eui.Component));
__reflect(Paihang_items.prototype, "Paihang_items");
//# sourceMappingURL=Paihang_items.js.map