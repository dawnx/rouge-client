var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ShouChong = (function (_super) {
    __extends(ShouChong, _super);
    function ShouChong(mainSence) {
        var _this = _super.call(this) || this;
        _this.isCharge = false;
        _this.m_mainSence = mainSence;
        _this.skinName = "resource/skin/shouchong.exml";
        return _this;
    }
    ShouChong.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.img_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickClose, this);
        this.chongzhi1.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz1, this);
        this.chongzhi2.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz2, this);
        this.chongzhi3.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz3, this);
        this.chongzhi4.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickCz4, this);
    };
    ShouChong.prototype.init = function () {
        PlayerApi.getPlayerInfo();
        var payCount = Data.GameContext.player.payCount; //充值数量
        console.log(payCount);
        var payLingqu = Data.GameContext.player.extraData; //是否领取
        console.log("充值数量" + payCount);
        if (!payCount)
            payCount = 0;
        if (payCount >= 20) {
            this.chongzhi1.width = 216;
            this.chongzhi1.height = 70;
            this.shouChongText1.text = "领取";
            this.isCharge = true;
            if (payLingqu.pay_reward_20 && payLingqu.pay_reward_20 == 1) {
                this.chongzhi1.source = "resource/assets/dating/toast-bg.png";
                this.shouChongText1.text = "已领取";
            }
        }
        else if (payCount >= 100) {
            this.chongzhi2.width = 216;
            this.chongzhi2.height = 70;
            this.shouChongText2.text = "领取";
            this.isCharge = true;
            if (payLingqu.pay_reward_100 && payLingqu.pay_reward_100 == 1) {
                this.chongzhi2.source = "resource/assets/dating/toast-bg.png";
                this.shouChongText1.text = "已领取";
            }
        }
        else if (payCount >= 200) {
            this.chongzhi3.width = 216;
            this.chongzhi3.height = 70;
            this.shouChongText3.text = "领取";
            this.isCharge = true;
            if (payLingqu.pay_reward_200 && payLingqu.pay_reward_200 == 1) {
                this.chongzhi3.source = "resource/assets/dating/toast-bg.png";
                this.shouChongText1.text = "已领取";
            }
        }
        else if (payCount >= 300) {
            this.chongzhi4.width = 216;
            this.chongzhi4.height = 70;
            this.shouChongText4.text = "领取";
            this.isCharge = true;
            if (payLingqu.pay_reward_300 && payLingqu.pay_reward_300 == 1) {
                this.chongzhi4.source = "resource/assets/dating/toast-bg.png";
                this.shouChongText1.text = "已领取";
                this.chongzhi4.touchEnabled = false;
            }
        }
    };
    ShouChong.prototype.onClickClose = function () {
        this.visible = false;
    };
    ShouChong.prototype.showChongZhiPanel = function () {
        if (this.chongzhiPanel == null) {
            this.chongzhiPanel = new Chongzhi(this.m_mainSence);
            this.addChild(this.chongzhiPanel);
        }
        else {
            this.chongzhiPanel.visible = true;
        }
    };
    ShouChong.prototype.onclickCz1 = function () {
        if (!this.isCharge) {
            this.showChongZhiPanel();
            this.isCharge = true;
        }
        else if (this.isCharge) {
            OrderApi.payReward(1);
        }
    };
    ShouChong.prototype.onclickCz2 = function () {
        if (!this.isCharge) {
            this.showChongZhiPanel();
            this.isCharge = true;
        }
        else if (this.isCharge) {
            OrderApi.payReward(2);
        }
    };
    ShouChong.prototype.onclickCz3 = function () {
        if (!this.isCharge) {
            this.showChongZhiPanel();
            this.isCharge = true;
        }
        else if (this.isCharge) {
            OrderApi.payReward(3);
        }
    };
    ShouChong.prototype.onclickCz4 = function () {
        if (!this.isCharge) {
            this.showChongZhiPanel();
            this.isCharge = true;
        }
        else if (this.isCharge) {
            OrderApi.payReward(4);
        }
    };
    return ShouChong;
}(eui.Component));
__reflect(ShouChong.prototype, "ShouChong");
//# sourceMappingURL=ShouChong.js.map