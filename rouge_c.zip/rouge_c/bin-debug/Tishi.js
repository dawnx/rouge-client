var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Tishi = (function (_super) {
    __extends(Tishi, _super);
    function Tishi(mainsence) {
        var _this = _super.call(this) || this;
        _this._mainsence = mainsence;
        _this.skinName = "resource/skin/tishi.exml";
        return _this;
    }
    Tishi.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.img_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickClose, this);
        this.btnQueding.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickQueding, this);
    };
    Tishi.prototype.init = function () {
    };
    //前往充值
    Tishi.prototype.onclickQueding = function () {
        this.visible = false;
    };
    Tishi.prototype.onclickClose = function () {
    };
    return Tishi;
}(eui.Component));
__reflect(Tishi.prototype, "Tishi");
//# sourceMappingURL=Tishi.js.map