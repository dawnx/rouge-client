var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Tishi1 = (function (_super) {
    __extends(Tishi1, _super);
    function Tishi1(mainsence) {
        var _this = _super.call(this) || this;
        _this._mainsence = mainsence;
        _this.skinName = "resource/skin/tishi1.exml";
        return _this;
    }
    Tishi1.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.img_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickClose, this);
        this.btnQueding.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickQueding, this);
    };
    Tishi1.prototype.init = function () {
    };
    //前往充值
    Tishi1.prototype.onclickQueding = function () {
        this.visible = false;
        // this.parent.removeChild(this);
        // this.stage.addChild(new Chongzhi(this._mainsence));
    };
    Tishi1.prototype.onclickClose = function () {
    };
    return Tishi1;
}(eui.Component));
__reflect(Tishi1.prototype, "Tishi1");
//# sourceMappingURL=Tishi1.js.map