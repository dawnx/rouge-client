var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Tishi2 = (function (_super) {
    __extends(Tishi2, _super);
    function Tishi2() {
        var _this = _super.call(this) || this;
        // this._mainsence = mainsence
        _this.skinName = "resource/skin/tishi2.exml";
        return _this;
    }
    Tishi2.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.img_close.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickClose, this);
        this.btnQueding.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onclickQueding, this);
    };
    Tishi2.prototype.init = function () {
    };
    //前往充值
    Tishi2.prototype.onclickQueding = function () {
        this.parent.removeChild(this);
        // this.stage.addChild(new Chongzhi(this._mainsence));
    };
    Tishi2.prototype.onclickClose = function () {
    };
    return Tishi2;
}(eui.Component));
__reflect(Tishi2.prototype, "Tishi2");
//# sourceMappingURL=Tishi2.js.map