var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var BaseApi = (function () {
    function BaseApi() {
    }
    // public static host: string = "http://192.168.1.112:8080/ct-admin/";
    BaseApi.get = function (uri, onComplete, onError, onProgress) {
        if (onComplete === void 0) { onComplete = null; }
        if (onError === void 0) { onError = null; }
        if (onProgress === void 0) { onProgress = null; }
        var request = new egret.HttpRequest();
        request.responseType = egret.HttpResponseType.TEXT;
        var url = this.host + uri;
        request.open(url, egret.HttpMethod.GET);
        request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        request.send();
        console.log("get url:" + url);
        request.addEventListener(egret.Event.COMPLETE, function (event) {
            var request = event.currentTarget;
            if (onComplete)
                onComplete(event);
        }, this);
        request.addEventListener(egret.IOErrorEvent.IO_ERROR, function (event) {
            var request = event.currentTarget;
            console.error("io error : ", url);
            if (onError)
                onError(event);
        }, this);
        request.addEventListener(egret.ProgressEvent.PROGRESS, function (event) {
            var request = event.currentTarget;
            console.log("on progress : ", url);
            if (onProgress)
                onProgress(event);
        }, this);
    };
    BaseApi.host = "http://kh.chitugame.com/ct-admin/";
    return BaseApi;
}());
__reflect(BaseApi.prototype, "BaseApi");
//# sourceMappingURL=BaseApi.js.map