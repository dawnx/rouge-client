var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var EventManager = (function (_super) {
    __extends(EventManager, _super);
    function EventManager() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EventManager.prototype.SendEvent = function (eventType, evtData) {
        if (evtData === void 0) { evtData = null; }
        var event = new egret.Event(eventType);
        event.data = evtData; //可选，若指定义事件上需要附加其他参数，可以在获取实例后在此处设置。
        this.dispatchEvent(event);
        egret.Event.release(event);
    };
    EventManager.getInstance = function () {
        if (!this.instance) {
            this.instance = new EventManager();
            console.log("EventManager Init   !");
        }
        return this.instance;
    };
    return EventManager;
}(egret.EventDispatcher));
__reflect(EventManager.prototype, "EventManager");
//# sourceMappingURL=EventManager.js.map