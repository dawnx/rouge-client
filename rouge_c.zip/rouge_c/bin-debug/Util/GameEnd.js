var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
// TypeScript file
var GameEnd = (function () {
    function GameEnd() {
    }
    GameEnd.RESULT_WIN = 1;
    GameEnd.RESULT_LOSE = 0;
    GameEnd.RESULT_RESET = 1;
    return GameEnd;
}());
__reflect(GameEnd.prototype, "GameEnd");
//# sourceMappingURL=GameEnd.js.map