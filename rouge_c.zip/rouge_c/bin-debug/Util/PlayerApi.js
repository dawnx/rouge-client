var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var PlayerApi = (function () {
    function PlayerApi() {
    }
    PlayerApi.getPlayerInfo = function () {
        var openId = egret.getOption("openId"); //取url后边的openid
        var uri = "player/getPlayerByOpenId?openId=o9lTh0_-PeTGbC_4dLG_TRsQAY-g";
        // let uri: string = "player/getPlayerByOpenId?openId=" + openId;
        BaseApi.get(uri, this.onGetComplete);
    };
    PlayerApi.onGetComplete = function (event) {
        // 获取到后台传回来的数据；
        var request = event.currentTarget;
        console.log("get data : ", request.response);
        // 解析
        var data = JSON.parse(request.response).data;
        Data.GameContext.player = data;
        EventManager.getInstance().SendEvent(ApiEvent.PLAYER_INFO);
    };
    /// 向服务器同步个人信息；
    PlayerApi.sendRankInfo = function (level, score, aliveTime) {
        //拼接参数 
        var params = "?level=" + level + "&score=" + score + "&aliveTime=" + aliveTime;
        var uri = "gameRouge/endGame" + params;
        // let uri: string = "gameRouge/endGame?openId=" + openId;
        BaseApi.get(uri, this.onSendRankInfoComplete);
    };
    PlayerApi.onSendRankInfoComplete = function (event) {
        // 获取到后台传回来的数据；
        var request = event.currentTarget;
        console.log("get data : ", request.response);
    };
    /// 获取排行榜信息；
    PlayerApi.getRankInfo = function (subGameId) {
        // let uri: string = "rank/getRankList?subGameId=o9lTh0_-PeTGbC_4dLG_TRsQAY-g";
        var uri = "rank/getRankList?subGameId=" + subGameId;
        BaseApi.get(uri, this.onGetRankInfoComplete);
    };
    PlayerApi.onGetRankInfoComplete = function (event) {
        // 获取到后台传回来的数据；
        var request = event.currentTarget;
        // 解析
        var data = JSON.parse(request.response).data;
        Data.GameContext.rankDataArray = data;
        console.log("get data : ", data);
    };
    return PlayerApi;
}());
__reflect(PlayerApi.prototype, "PlayerApi");
//# sourceMappingURL=PlayerApi.js.map