var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var RougeGameApi = (function () {
    function RougeGameApi() {
    }
    /// 游戏入口调用；
    RougeGameApi.startGame = function (subGameId, goodsType, goodsFenqu, gameType, isReset) {
        var openId = Data.GameContext.player.openId; //取url后边的openid
        console.log("openId   " + openId);
        //拼接参数 
        var params = "?openId=" + openId + "&subGameId=" + subGameId + "&goodsType=" + goodsType + "&goodsFenqu=" + goodsFenqu + "&gameType=" + gameType + "&reset=" + isReset;
        ;
        // var params = "?openId=o9lTh0_-PeTGbC_4dLG_TRsQAY-g" + "&subGameId=" + subGameId + "&goodsType=" + goodsType + "&goodsFenqu=" + goodsFenqu + "&gameType=" + gameType + "&reset=" + isReset; 
        var uri = "gameRouge/startGame" + params;
        BaseApi.get(uri, this.onCompleteGameStart);
    };
    RougeGameApi.onCompleteGameStart = function (event) {
        console.log("Send Success!!!");
        // 获取到后台传回来的数据；
        var request = event.currentTarget;
        console.log("get data : ", request.response);
        // 解析
        var data = JSON.parse(request.response).data;
        console.log("成功！ 调起Exchange请求！");
        PlayerApi.getPlayerInfo();
    };
    /// 游戏结束   调用；
    RougeGameApi.gameEnd = function (subGameId, isWin, level, score, aliveTime) {
        var openId = Data.GameContext.player.openId; //取url后边的openid
        console.log("openId   " + openId);
        //拼接参数 
        var params = "?openId=" + openId + "&subGameId=" + subGameId + "&win=" + isWin + "&level=" + level + "&score=" + score + "&aliveTime=" + aliveTime;
        //拼接参数 
        //var params = "?openId=" + openId + "&subGameId=" + subGameId + "&win=" + isWin + "&level=" + level + "&score=" + score + "&aliveTime=" + aliveTime;
        var uri = "gameRouge/endGame" + params;
        BaseApi.get(uri, this.onCompleteGameEnd);
    };
    RougeGameApi.onCompleteGameEnd = function (event) {
        console.log("Send Success!!!");
        // 获取到后台传回来的数据；
        var request = event.currentTarget;
        console.log("get data : ", request.response);
        // 解析
        var data = JSON.parse(request.response).data;
        PlayerApi.getPlayerInfo();
    };
    return RougeGameApi;
}());
__reflect(RougeGameApi.prototype, "RougeGameApi");
//# sourceMappingURL=RougeGameApi.js.map