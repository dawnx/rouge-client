var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var XsOver = (function (_super) {
    __extends(XsOver, _super);
    function XsOver(gamemain, score, type, goodsItemData, m_mainsence) {
        var _this = _super.call(this) || this;
        _this._score = score;
        _this._type = type;
        _this.goodsItemData = goodsItemData;
        _this.m_mainsence = m_mainsence;
        _this._gamemain = gamemain;
        _this.skinName = "resource/skin/xsover.exml";
        return _this;
    }
    XsOver.prototype.childrenCreated = function () {
        _super.prototype.childrenCreated.call(this);
        this.init();
        this.btn_fangqi.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickFangqi, this);
        this.btn_fangqi1.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickFangqi, this);
        this.btn_reset.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onClickReset, this);
    };
    XsOver.prototype.init = function () {
        egret.log(this._score);
        this.lb_score.text = "游戏结束！恭喜您获得了" + this._score + "分!";
    };
    XsOver.prototype.onClickFangqi = function () {
        this.addChild(new MainSence());
    };
    XsOver.prototype.onClickReset = function () {
        console.log(Data.GameContext.player.goldNumber);
        //如果金币小于等于0 
        if (Data.GameContext.player.goldNumber >= 50) {
            console.log("金币足够");
            RougeGameApi.startGame(this.goodsItemData.subGameId, this.goodsItemData.goodsType, this.goodsItemData.goodsFenqu, this.goodsItemData.gameType, GameEnd.RESULT_RESET);
            PlayerApi.getPlayerInfo();
            console.log("*******Send   ed ");
            console.log("*******GameEnd.RESULT_RESET  ed " + GameEnd.RESULT_RESET);
            // AccountData.accoundData.gold -= this.goodsItemData.goodsFenqu / 2;
            console.log("AccountData.accoundData.gold   :" + Data.GameContext.player.goldNumber);
            this._gamemain.initGame2();
        }
        {
            //金币不足，前往充值提示
            this.addChild(new Tishi2());
        }
    };
    return XsOver;
}(eui.Component));
__reflect(XsOver.prototype, "XsOver");
//# sourceMappingURL=XsOver.js.map