window.skins={};
                function __extends(d, b) {
                    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
                        function __() {
                            this.constructor = d;
                        }
                    __.prototype = b.prototype;
                    d.prototype = new __();
                };
                window.generateEUI = {};
                generateEUI.paths = {};
                generateEUI.styles = undefined;
                generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","eui.CheckBox":"resource/eui_skins/CheckBoxSkin.exml","eui.HScrollBar":"resource/eui_skins/HScrollBarSkin.exml","eui.HSlider":"resource/eui_skins/HSliderSkin.exml","eui.Panel":"resource/eui_skins/PanelSkin.exml","eui.TextInput":"resource/eui_skins/TextInputSkin.exml","eui.ProgressBar":"resource/eui_skins/ProgressBarSkin.exml","eui.RadioButton":"resource/eui_skins/RadioButtonSkin.exml","eui.Scroller":"resource/eui_skins/ScrollerSkin.exml","eui.ToggleSwitch":"resource/eui_skins/ToggleSwitchSkin.exml","eui.VScrollBar":"resource/eui_skins/VScrollBarSkin.exml","eui.VSlider":"resource/eui_skins/VSliderSkin.exml","eui.ItemRenderer":"resource/eui_skins/ItemRendererSkin.exml","GameMain":"resource/eui_skins/GameMain.exml"};generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay","iconDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i(),this.iconDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.iconDisplay_i = function () {
		var t = new eui.Image();
		this.iconDisplay = t;
		t.horizontalCenter = 0;
		t.verticalCenter = 0;
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/CheckBoxSkin.exml'] = window.skins.CheckBoxSkin = (function (_super) {
	__extends(CheckBoxSkin, _super);
	function CheckBoxSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","checkbox_select_disabled_png")
				])
		];
	}
	var _proto = CheckBoxSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "checkbox_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return CheckBoxSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HScrollBarSkin.exml'] = window.skins.HScrollBarSkin = (function (_super) {
	__extends(HScrollBarSkin, _super);
	function HScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = HScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 8;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.verticalCenter = 0;
		t.width = 30;
		return t;
	};
	return HScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/HSliderSkin.exml'] = window.skins.HSliderSkin = (function (_super) {
	__extends(HSliderSkin, _super);
	function HSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 8;
		this.minWidth = 20;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = HSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.anchorOffsetX = 0;
		t.fillMode = "scale";
		t.height = 15;
		t.scale9Grid = new egret.Rectangle(5,7,7,1);
		t.source = "track_png";
		t.verticalCenter = 0.5;
		t.percentWidth = 100;
		t.x = 0;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.source = "thumb_png";
		t.verticalCenter = 0;
		t.x = 0;
		return t;
	};
	return HSliderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ItemRendererSkin.exml'] = window.skins.ItemRendererSkin = (function (_super) {
	__extends(ItemRendererSkin, _super);
	function ItemRendererSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","button_down_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
		];
		
		eui.Binding.$bindProperties(this, ["hostComponent.data"],[0],this.labelDisplay,"text");
	}
	var _proto = ItemRendererSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.fontFamily = "Tahoma";
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ItemRendererSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/PanelSkin.exml'] = window.skins.PanelSkin = (function (_super) {
	__extends(PanelSkin, _super);
	function PanelSkin() {
		_super.call(this);
		this.skinParts = ["titleDisplay","moveArea","closeButton"];
		
		this.minHeight = 230;
		this.minWidth = 450;
		this.elementsContent = [this._Image1_i(),this.moveArea_i(),this.closeButton_i()];
	}
	var _proto = PanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(2,2,12,12);
		t.source = "border_png";
		t.top = 0;
		return t;
	};
	_proto.moveArea_i = function () {
		var t = new eui.Group();
		this.moveArea = t;
		t.height = 45;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image2_i(),this.titleDisplay_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "header_png";
		t.top = 0;
		return t;
	};
	_proto.titleDisplay_i = function () {
		var t = new eui.Label();
		this.titleDisplay = t;
		t.fontFamily = "Tahoma";
		t.left = 15;
		t.right = 5;
		t.size = 20;
		t.textColor = 0xFFFFFF;
		t.verticalCenter = 0;
		t.wordWrap = false;
		return t;
	};
	_proto.closeButton_i = function () {
		var t = new eui.Button();
		this.closeButton = t;
		t.bottom = 5;
		t.horizontalCenter = 0;
		t.label = "close";
		return t;
	};
	return PanelSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ProgressBarSkin.exml'] = window.skins.ProgressBarSkin = (function (_super) {
	__extends(ProgressBarSkin, _super);
	function ProgressBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb","labelDisplay"];
		
		this.minHeight = 18;
		this.minWidth = 30;
		this.elementsContent = [this._Image1_i(),this.thumb_i(),this.labelDisplay_i()];
	}
	var _proto = ProgressBarSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_pb_png";
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.percentHeight = 100;
		t.source = "thumb_pb_png";
		t.percentWidth = 100;
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.horizontalCenter = 0;
		t.size = 15;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		t.verticalCenter = 0;
		return t;
	};
	return ProgressBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/RadioButtonSkin.exml'] = window.skins.RadioButtonSkin = (function (_super) {
	__extends(RadioButtonSkin, _super);
	function RadioButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.elementsContent = [this._Group1_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","alpha",0.7)
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","alpha",0.5)
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_up_png")
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_down_png")
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image1","source","radiobutton_select_disabled_png")
				])
		];
	}
	var _proto = RadioButtonSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.percentHeight = 100;
		t.percentWidth = 100;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.verticalAlign = "middle";
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.alpha = 1;
		t.fillMode = "scale";
		t.source = "radiobutton_unselect_png";
		return t;
	};
	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.fontFamily = "Tahoma";
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0x707070;
		t.verticalAlign = "middle";
		return t;
	};
	return RadioButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ScrollerSkin.exml'] = window.skins.ScrollerSkin = (function (_super) {
	__extends(ScrollerSkin, _super);
	function ScrollerSkin() {
		_super.call(this);
		this.skinParts = ["horizontalScrollBar","verticalScrollBar"];
		
		this.minHeight = 20;
		this.minWidth = 20;
		this.elementsContent = [this.horizontalScrollBar_i(),this.verticalScrollBar_i()];
	}
	var _proto = ScrollerSkin.prototype;

	_proto.horizontalScrollBar_i = function () {
		var t = new eui.HScrollBar();
		this.horizontalScrollBar = t;
		t.bottom = 0;
		t.percentWidth = 100;
		return t;
	};
	_proto.verticalScrollBar_i = function () {
		var t = new eui.VScrollBar();
		this.verticalScrollBar = t;
		t.percentHeight = 100;
		t.right = 0;
		return t;
	};
	return ScrollerSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/TextInputSkin.exml'] = window.skins.TextInputSkin = (function (_super) {
	__extends(TextInputSkin, _super);
	function TextInputSkin() {
		_super.call(this);
		this.skinParts = ["textDisplay","promptDisplay"];
		
		this.minHeight = 40;
		this.minWidth = 300;
		this.elementsContent = [this._Image1_i(),this._Rect1_i(),this.textDisplay_i()];
		this.promptDisplay_i();
		
		this.states = [
			new eui.State ("normal",
				[
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("textDisplay","textColor",0xff0000)
				])
			,
			new eui.State ("normalWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
			,
			new eui.State ("disabledWithPrompt",
				[
					new eui.AddItems("promptDisplay","",1,"")
				])
		];
	}
	var _proto = TextInputSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.percentHeight = 100;
		t.scale9Grid = new egret.Rectangle(1,3,8,8);
		t.source = "button_up_png";
		t.percentWidth = 100;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillColor = 0xffffff;
		t.percentHeight = 100;
		t.percentWidth = 100;
		return t;
	};
	_proto.textDisplay_i = function () {
		var t = new eui.EditableText();
		this.textDisplay = t;
		t.height = 24;
		t.left = "10";
		t.right = "10";
		t.size = 20;
		t.textColor = 0x000000;
		t.verticalCenter = "0";
		t.percentWidth = 100;
		return t;
	};
	_proto.promptDisplay_i = function () {
		var t = new eui.Label();
		this.promptDisplay = t;
		t.height = 24;
		t.left = 10;
		t.right = 10;
		t.size = 20;
		t.textColor = 0xa9a9a9;
		t.touchEnabled = false;
		t.verticalCenter = 0;
		t.percentWidth = 100;
		return t;
	};
	return TextInputSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ToggleSwitchSkin.exml'] = window.skins.ToggleSwitchSkin = (function (_super) {
	__extends(ToggleSwitchSkin, _super);
	function ToggleSwitchSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.elementsContent = [this._Image1_i(),this._Image2_i()];
		this.states = [
			new eui.State ("up",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("down",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("disabled",
				[
					new eui.SetProperty("_Image1","source","off_png")
				])
			,
			new eui.State ("upAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("downAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
			,
			new eui.State ("disabledAndSelected",
				[
					new eui.SetProperty("_Image2","horizontalCenter",18)
				])
		];
	}
	var _proto = ToggleSwitchSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		this._Image1 = t;
		t.source = "on_png";
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		this._Image2 = t;
		t.horizontalCenter = -18;
		t.source = "handle_png";
		t.verticalCenter = 0;
		return t;
	};
	return ToggleSwitchSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VScrollBarSkin.exml'] = window.skins.VScrollBarSkin = (function (_super) {
	__extends(VScrollBarSkin, _super);
	function VScrollBarSkin() {
		_super.call(this);
		this.skinParts = ["thumb"];
		
		this.minHeight = 20;
		this.minWidth = 8;
		this.elementsContent = [this.thumb_i()];
	}
	var _proto = VScrollBarSkin.prototype;

	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.height = 30;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(3,3,2,2);
		t.source = "roundthumb_png";
		t.width = 8;
		return t;
	};
	return VScrollBarSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/VSliderSkin.exml'] = window.skins.VSliderSkin = (function (_super) {
	__extends(VSliderSkin, _super);
	function VSliderSkin() {
		_super.call(this);
		this.skinParts = ["track","thumb"];
		
		this.minHeight = 30;
		this.minWidth = 25;
		this.elementsContent = [this.track_i(),this.thumb_i()];
	}
	var _proto = VSliderSkin.prototype;

	_proto.track_i = function () {
		var t = new eui.Image();
		this.track = t;
		t.percentHeight = 100;
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(1,1,4,4);
		t.source = "track_png";
		t.width = 7;
		return t;
	};
	_proto.thumb_i = function () {
		var t = new eui.Image();
		this.thumb = t;
		t.horizontalCenter = 0;
		t.source = "thumb_png";
		return t;
	};
	return VSliderSkin;
})(eui.Skin);generateEUI.paths['resource/skin/begin.exml'] = window.begin = (function (_super) {
	__extends(begin, _super);
	var begin$Skin1 = 	(function (_super) {
		__extends(begin$Skin1, _super);
		function begin$Skin1() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = begin$Skin1.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_05_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return begin$Skin1;
	})(eui.Skin);

	var begin$Skin2 = 	(function (_super) {
		__extends(begin$Skin2, _super);
		function begin$Skin2() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = begin$Skin2.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_03_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return begin$Skin2;
	})(eui.Skin);

	function begin() {
		_super.call(this);
		this.skinParts = ["gp_paihang","scroller","lb_tishi","btn_share","btn_begin"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Group3_i()];
	}
	var _proto = begin.prototype;

	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image1_i(),this._Group1_i(),this.scroller_i(),this.lb_tishi_i(),this._Group2_i(),this._Label6_i(),this._Label7_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 1334;
		t.scale9Grid = new egret.Rectangle(38,25,9,7);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_08_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image2_i(),this._Image3_i(),this._Label1_i(),this._Label2_i(),this._Label3_i(),this._Label4_i(),this._Label5_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 40;
		t.text = "排行榜";
		t.textColor = 0xffffff;
		t.x = 313.5;
		t.y = 19.5;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "名次";
		t.textColor = 0x666666;
		t.x = 103.6;
		t.y = 91.77;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "头像";
		t.textColor = 0x666666;
		t.x = 265.3333333333333;
		t.y = 91.77;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "名字";
		t.textColor = 0x666666;
		t.x = 426.66666666666663;
		t.y = 91.77;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "成绩";
		t.textColor = 0x666666;
		t.x = 588.4;
		t.y = 91.77;
		return t;
	};
	_proto.scroller_i = function () {
		var t = new eui.Scroller();
		this.scroller = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 996;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 136;
		t.viewport = this.gp_paihang_i();
		return t;
	};
	_proto.gp_paihang_i = function () {
		var t = new eui.Group();
		this.gp_paihang = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 938;
		t.width = 789.39;
		return t;
	};
	_proto.lb_tishi_i = function () {
		var t = new eui.Label();
		this.lb_tishi = t;
		t.text = "体验模式无收益，点击下方开始游戏";
		t.textAlign = "center";
		t.textColor = 0x000000;
		t.verticalAlign = "middle";
		t.width = 750;
		t.x = 0;
		t.y = 516;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.width = 750;
		t.x = 0;
		t.y = 1198;
		t.elementsContent = [this._Image4_i(),this.btn_share_i(),this.btn_begin_i()];
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.anchorOffsetY = 0;
		t.height = 192;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = -56;
		return t;
	};
	_proto.btn_share_i = function () {
		var t = new eui.Button();
		this.btn_share = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.label = "分享游戏";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 106;
		t.y = 4;
		t.skinName = begin$Skin1;
		return t;
	};
	_proto.btn_begin_i = function () {
		var t = new eui.Button();
		this.btn_begin = t;
		t.label = "开始游戏";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 428;
		t.y = 4;
		t.skinName = begin$Skin2;
		return t;
	};
	_proto._Label6_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "发奖倒计时：";
		t.textColor = 0x000000;
		t.visible = false;
		t.x = 190;
		t.y = 104;
		return t;
	};
	_proto._Label7_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "131322132";
		t.textColor = 0x000000;
		t.visible = false;
		t.x = 342;
		t.y = 104;
		return t;
	};
	return begin;
})(eui.Skin);generateEUI.paths['resource/skin/chongzhi.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	function goods_item() {
		_super.call(this);
		this.skinParts = ["rect_back","chongzhi1","chongzhi2","chongzhi3","chongzhi4","chongzhi5","chongzhi6"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Group7_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Group7_i = function () {
		var t = new eui.Group();
		t.height = 1334;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this._Label1_i(),this._Label2_i(),this.rect_back_i(),this._Group1_i(),this._Group2_i(),this._Group3_i(),this._Group4_i(),this._Group5_i(),this._Group6_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 1334;
		t.scale9Grid = new egret.Rectangle(38,25,9,7);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_08_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_button_02_png";
		t.x = 24.34;
		t.y = 15.5;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_button_01_03_png";
		t.x = 680;
		t.y = 20;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 32;
		t.text = "游戏充值";
		t.x = 318;
		t.y = 20.5;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "返回";
		t.x = 76;
		t.y = 20.5;
		return t;
	};
	_proto.rect_back_i = function () {
		var t = new eui.Rect();
		this.rect_back = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 30;
		t.width = 108.67;
		t.x = 27.33;
		t.y = 20;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 89;
		t.elementsContent = [this._Image5_i(),this._Image6_i(),this._Image7_i(),this._Label3_i(),this._Label4_i(),this._Label5_i(),this.chongzhi1_i(),this._Label6_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 0;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_icon_01_png";
		t.x = 63;
		t.y = 30;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.size = 24;
		t.text = "18颗钻石";
		t.x = 20;
		t.y = 81.67;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.right = 303;
		t.size = 48;
		t.text = "￥6元";
		t.textColor = 0xc61717;
		t.y = 20.17;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.horizontalCenter = 0;
		t.size = 26;
		t.text = "首充双倍";
		t.textColor = 0x333333;
		t.y = 79.67;
		return t;
	};
	_proto.chongzhi1_i = function () {
		var t = new eui.Image();
		this.chongzhi1 = t;
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 543;
		t.y = 43.67;
		return t;
	};
	_proto._Label6_i = function () {
		var t = new eui.Label();
		t.rotation = 1.31;
		t.size = 28;
		t.text = "充值";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 590;
		t.y = 53.17;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 234.26666666666665;
		t.elementsContent = [this._Image8_i(),this._Image9_i(),this._Image10_i(),this._Label7_i(),this._Label8_i(),this._Label9_i(),this.chongzhi2_i(),this._Label10_i()];
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 0;
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_01_png";
		t.x = 63;
		t.y = 22.8;
		return t;
	};
	_proto._Label7_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "18颗钻石";
		t.x = 20;
		t.y = 74.47;
		return t;
	};
	_proto._Label8_i = function () {
		var t = new eui.Label();
		t.right = 303;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 48;
		t.text = "￥12元";
		t.textColor = 0xC61717;
		t.y = 22.8;
		return t;
	};
	_proto._Label9_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "首充双倍";
		t.textColor = 0x333333;
		t.y = 74.47;
		return t;
	};
	_proto.chongzhi2_i = function () {
		var t = new eui.Image();
		this.chongzhi2 = t;
		t.scaleX = 0.6999999999999998;
		t.scaleY = 0.6999999999999998;
		t.source = "mmm_dating_button_03_png";
		t.x = 543;
		t.y = 36.47;
		return t;
	};
	_proto._Label10_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "充值";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 590;
		t.y = 45.97;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 380.5333333333335;
		t.elementsContent = [this._Image11_i(),this._Image12_i(),this._Image13_i(),this._Label11_i(),this._Label12_i(),this._Label13_i(),this.chongzhi3_i(),this._Label14_i()];
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 0;
		return t;
	};
	_proto._Image13_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_01_png";
		t.x = 63;
		t.y = 22.266666666666595;
		return t;
	};
	_proto._Label11_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "18颗钻石";
		t.x = 20;
		t.y = 73.93666666666661;
		return t;
	};
	_proto._Label12_i = function () {
		var t = new eui.Label();
		t.right = 303;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 48;
		t.text = "￥15元";
		t.textColor = 0xC61717;
		t.y = 22.266666666666595;
		return t;
	};
	_proto._Label13_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "首充双倍";
		t.textColor = 0x333333;
		t.y = 73.93666666666661;
		return t;
	};
	_proto.chongzhi3_i = function () {
		var t = new eui.Image();
		this.chongzhi3 = t;
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 543;
		t.y = 35.93666666666661;
		return t;
	};
	_proto._Label14_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "充值";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 590;
		t.y = 45.44;
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 525.8000000000002;
		t.elementsContent = [this._Image14_i(),this._Image15_i(),this._Image16_i(),this._Image17_i(),this._Image18_i(),this._Label15_i(),this._Label16_i(),this._Label17_i(),this.chongzhi4_i(),this._Label18_i()];
		return t;
	};
	_proto._Image14_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image15_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 0;
		return t;
	};
	_proto._Image16_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 3.4;
		return t;
	};
	_proto._Image17_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 3.4;
		return t;
	};
	_proto._Image18_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_01_png";
		t.x = 63;
		t.y = 25.67;
		return t;
	};
	_proto._Label15_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "18颗钻石";
		t.x = 20;
		t.y = 77.34;
		return t;
	};
	_proto._Label16_i = function () {
		var t = new eui.Label();
		t.right = 303;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 48;
		t.text = "￥20元";
		t.textColor = 0xC61717;
		t.y = 25.67;
		return t;
	};
	_proto._Label17_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "首充双倍";
		t.textColor = 0x333333;
		t.y = 77.34;
		return t;
	};
	_proto.chongzhi4_i = function () {
		var t = new eui.Image();
		this.chongzhi4 = t;
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 543;
		t.y = 39.34;
		return t;
	};
	_proto._Label18_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "充值";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 590;
		t.y = 48.84;
		return t;
	};
	_proto._Group5_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 671.2000000000002;
		t.elementsContent = [this._Image19_i(),this._Image20_i(),this._Image21_i(),this._Image22_i(),this._Image23_i(),this._Label19_i(),this._Label20_i(),this._Label21_i(),this.chongzhi5_i(),this._Label22_i()];
		return t;
	};
	_proto._Image19_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image20_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 0;
		return t;
	};
	_proto._Image21_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 3.4;
		return t;
	};
	_proto._Image22_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 3.4;
		return t;
	};
	_proto._Image23_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_01_png";
		t.x = 63;
		t.y = 25.67;
		return t;
	};
	_proto._Label19_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "18颗钻石";
		t.x = 20;
		t.y = 77.34;
		return t;
	};
	_proto._Label20_i = function () {
		var t = new eui.Label();
		t.right = 303;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 48;
		t.text = "￥50元";
		t.textColor = 0xC61717;
		t.y = 25.67;
		return t;
	};
	_proto._Label21_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "首充双倍";
		t.textColor = 0x333333;
		t.y = 77.34;
		return t;
	};
	_proto.chongzhi5_i = function () {
		var t = new eui.Image();
		this.chongzhi5 = t;
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 543;
		t.y = 39.34;
		return t;
	};
	_proto._Label22_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "充值";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 590;
		t.y = 48.84;
		return t;
	};
	_proto._Group6_i = function () {
		var t = new eui.Group();
		t.height = 136;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 816.6;
		t.elementsContent = [this._Image24_i(),this._Image25_i(),this._Image26_i(),this._Image27_i(),this._Image28_i(),this._Label23_i(),this._Label24_i(),this._Label25_i(),this.chongzhi6_i(),this._Label26_i()];
		return t;
	};
	_proto._Image24_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image25_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 0;
		return t;
	};
	_proto._Image26_i = function () {
		var t = new eui.Image();
		t.height = 136;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 3.4;
		return t;
	};
	_proto._Image27_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_chongzhi_Floor_01_03_png";
		t.x = 5;
		t.y = 3.4;
		return t;
	};
	_proto._Image28_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_01_png";
		t.x = 63;
		t.y = 25.67;
		return t;
	};
	_proto._Label23_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "18颗钻石";
		t.x = 20;
		t.y = 77.34;
		return t;
	};
	_proto._Label24_i = function () {
		var t = new eui.Label();
		t.right = 303;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 48;
		t.text = "￥100元";
		t.textColor = 0xC61717;
		t.y = 25.67;
		return t;
	};
	_proto._Label25_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "首充双倍";
		t.textColor = 0x333333;
		t.y = 77.34;
		return t;
	};
	_proto.chongzhi6_i = function () {
		var t = new eui.Image();
		this.chongzhi6 = t;
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 543;
		t.y = 39.34;
		return t;
	};
	_proto._Label26_i = function () {
		var t = new eui.Label();
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "充值";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 590;
		t.y = 48.84;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/duihuan.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_close","duihuan","gold","demons","group"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Image2_i(),this._Image3_i(),this.img_close_i(),this.group_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 414;
		t.scale9Grid = new egret.Rectangle(15,15,96,96);
		t.source = "mmm_dating_Backplane_07_png";
		t.width = 676;
		t.x = 37;
		t.y = 346;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_header_01_png";
		t.x = 148.5;
		t.y = 283.5;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_Art-word_04_03_png";
		t.x = 338;
		t.y = 306;
		return t;
	};
	_proto.img_close_i = function () {
		var t = new eui.Image();
		this.img_close = t;
		t.source = "mmm_dating_button_02_03_png";
		t.x = 344;
		t.y = 1020;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 414;
		t.width = 676;
		t.x = 37;
		t.y = 346;
		t.elementsContent = [this._Label1_i(),this._Image4_i(),this._Image5_i(),this._Image6_i(),this._Image7_i(),this.duihuan_i(),this._Label2_i(),this._Image8_i(),this.gold_i(),this.demons_i()];
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "1钻石兑换3金币";
		t.textColor = 0x333333;
		t.x = 246.5;
		t.y = 54.64;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_01_png";
		t.x = 119;
		t.y = 122.65;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_02_png";
		t.x = 398.34;
		t.y = 124.65;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.scale9Grid = new egret.Rectangle(21,17,2,1);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_frame_01_png";
		t.width = 114;
		t.x = 169;
		t.y = 122.65;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.scale9Grid = new egret.Rectangle(21,17,2,1);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_frame_01_png";
		t.width = 114;
		t.x = 446;
		t.y = 124.65;
		return t;
	};
	_proto.duihuan_i = function () {
		var t = new eui.Image();
		this.duihuan = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_button_03_png";
		t.x = 230;
		t.y = 304;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "兑换";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.x = 309.5;
		t.y = 325;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scale9Grid = new egret.Rectangle(11,7,2,1);
		t.source = "mmm_dating_bar_01_png";
		t.verticalCenter = 0;
		t.width = 452;
		return t;
	};
	_proto.gold_i = function () {
		var t = new eui.Label();
		this.gold = t;
		t.size = 24;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0xe90000;
		t.verticalAlign = "middle";
		t.width = 77;
		t.x = 463.5;
		t.y = 129;
		return t;
	};
	_proto.demons_i = function () {
		var t = new eui.Label();
		this.demons = t;
		t.anchorOffsetX = 0;
		t.size = 24;
		t.text = "0";
		t.textAlign = "center";
		t.textColor = 0x16d531;
		t.verticalAlign = "middle";
		t.width = 77;
		t.x = 186.5;
		t.y = 129;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/duihuanitem.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_close","edu","btnQueding","group"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Image2_i(),this._Image3_i(),this.img_close_i(),this.group_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 414;
		t.scale9Grid = new egret.Rectangle(15,15,96,96);
		t.source = "mmm_dating_Backplane_07_png";
		t.width = 676;
		t.x = 37;
		t.y = 346;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_header_01_png";
		t.x = 148.5;
		t.y = 283.5;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_Art-word_04_03_png";
		t.x = 338;
		t.y = 306;
		return t;
	};
	_proto.img_close_i = function () {
		var t = new eui.Image();
		this.img_close = t;
		t.source = "mmm_dating_button_02_03_png";
		t.visible = false;
		t.x = 344;
		t.y = 1020;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 414;
		t.width = 676;
		t.x = 37;
		t.y = 346;
		t.elementsContent = [this.edu_i(),this.btnQueding_i(),this._Label1_i()];
		return t;
	};
	_proto.edu_i = function () {
		var t = new eui.Label();
		this.edu = t;
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "此次兑换额度为";
		t.textColor = 0x333333;
		t.touchEnabled = false;
		t.x = 240;
		t.y = 133;
		return t;
	};
	_proto.btnQueding_i = function () {
		var t = new eui.Image();
		this.btnQueding = t;
		t.source = "mmm_dating_button_03_png";
		t.x = 230;
		t.y = 266;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "确定";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.x = 310;
		t.y = 287;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/gamemain.exml'] = window.gamemain = (function (_super) {
	__extends(gamemain, _super);
	var gamemain$Skin3 = 	(function (_super) {
		__extends(gamemain$Skin3, _super);
		function gamemain$Skin3() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = gamemain$Skin3.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_youxi_button_04_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return gamemain$Skin3;
	})(eui.Skin);

	function gamemain() {
		_super.call(this);
		this.skinParts = ["gp_circle","img_juzi","rect_dangban","lb_time","btn_back","lb_guan","lb_rougeNum","gp_rouge","rect_guan","img_guan","gp_guan"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = gamemain.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image1_i(),this.gp_circle_i(),this.img_juzi_i(),this.rect_dangban_i(),this._Image2_i(),this._Image3_i(),this._Image4_i(),this.lb_time_i(),this.btn_back_i(),this.lb_guan_i(),this.lb_rougeNum_i(),this.gp_rouge_i(),this.gp_guan_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_background_01_png";
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto.gp_circle_i = function () {
		var t = new eui.Group();
		this.gp_circle = t;
		t.anchorOffsetX = 50;
		t.anchorOffsetY = 50;
		t.height = 100;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 100;
		t.x = 375;
		t.y = 500;
		return t;
	};
	_proto.img_juzi_i = function () {
		var t = new eui.Image();
		this.img_juzi = t;
		t.anchorOffsetX = 190;
		t.anchorOffsetY = 190;
		t.height = 380;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_picture_03_png";
		t.width = 380;
		t.x = 375;
		t.y = 500;
		return t;
	};
	_proto.rect_dangban_i = function () {
		var t = new eui.Rect();
		this.rect_dangban = t;
		t.fillAlpha = 0;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_Backplane_01_png";
		t.x = 42;
		t.y = 100;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_Special effect_01_png";
		t.x = 42;
		t.y = 100.01;
		return t;
	};
	_proto.lb_time_i = function () {
		var t = new eui.Label();
		this.lb_time = t;
		t.height = 51;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 45;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0x000000;
		t.verticalAlign = "middle";
		t.width = 51;
		t.x = 59.51;
		t.y = 120.51;
		return t;
	};
	_proto.btn_back_i = function () {
		var t = new eui.Button();
		this.btn_back = t;
		t.horizontalCenter = -316.5;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 42;
		t.y = 23;
		t.skinName = gamemain$Skin3;
		return t;
	};
	_proto.lb_guan_i = function () {
		var t = new eui.Label();
		this.lb_guan = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 45;
		t.text = "第1关";
		t.textColor = 0x000000;
		t.x = 475;
		t.y = 17;
		return t;
	};
	_proto.lb_rougeNum_i = function () {
		var t = new eui.Label();
		this.lb_rougeNum = t;
		t.height = 51;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 30;
		t.text = "";
		t.textAlign = "center";
		t.textColor = 0xffffff;
		t.verticalAlign = "middle";
		t.x = 24.6;
		t.y = 1160.81;
		return t;
	};
	_proto.gp_rouge_i = function () {
		var t = new eui.Group();
		this.gp_rouge = t;
		t.anchorOffsetY = 0;
		t.height = 573.39;
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 200;
		t.x = 0;
		t.y = 760.61;
		return t;
	};
	_proto.gp_guan_i = function () {
		var t = new eui.Group();
		this.gp_guan = t;
		t.height = 1334;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.rect_guan_i(),this.img_guan_i()];
		return t;
	};
	_proto.rect_guan_i = function () {
		var t = new eui.Rect();
		this.rect_guan = t;
		t.fillAlpha = 0.7;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.img_guan_i = function () {
		var t = new eui.Image();
		this.img_guan = t;
		t.source = "guan2_png";
		t.x = 272;
		t.y = 500;
		return t;
	};
	return gamemain;
})(eui.Skin);generateEUI.paths['resource/skin/gameover.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	var goods_item$Skin4 = 	(function (_super) {
		__extends(goods_item$Skin4, _super);
		function goods_item$Skin4() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = goods_item$Skin4.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_05_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return goods_item$Skin4;
	})(eui.Skin);

	var goods_item$Skin5 = 	(function (_super) {
		__extends(goods_item$Skin5, _super);
		function goods_item$Skin5() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = goods_item$Skin5.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_04_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return goods_item$Skin5;
	})(eui.Skin);

	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_juzi","lb_score","btn_fangqi","btn_reset","img_juzi0","btn_fangqi1","gp_tiyan","img_shibai"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this.img_juzi_i(),this._Image2_i(),this.lb_score_i(),this.btn_fangqi_i(),this.btn_reset_i(),this.gp_tiyan_i(),this.img_shibai_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "mmm_youxi_background_01_png";
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto.img_juzi_i = function () {
		var t = new eui.Image();
		this.img_juzi = t;
		t.anchorOffsetX = 190;
		t.anchorOffsetY = 190;
		t.height = 380;
		t.source = "mmm_youxi_picture_03_png";
		t.width = 380;
		t.x = 375;
		t.y = 550;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.lb_score_i = function () {
		var t = new eui.Label();
		this.lb_score = t;
		t.text = "好可惜，距离获奖就差那么一点点";
		t.textColor = 0x000000;
		t.x = 169.5;
		t.y = 191.22;
		return t;
	};
	_proto.btn_fangqi_i = function () {
		var t = new eui.Button();
		this.btn_fangqi = t;
		t.label = "放弃重玩";
		t.x = 50;
		t.y = 1014.79;
		t.skinName = goods_item$Skin4;
		return t;
	};
	_proto.btn_reset_i = function () {
		var t = new eui.Button();
		this.btn_reset = t;
		t.height = 72;
		t.label = "金币继续";
		t.width = 216;
		t.x = 496.5;
		t.y = 1014.79;
		t.skinName = goods_item$Skin5;
		return t;
	};
	_proto.gp_tiyan_i = function () {
		var t = new eui.Group();
		this.gp_tiyan = t;
		t.height = 1334;
		t.visible = false;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image3_i(),this.img_juzi0_i(),this._Image4_i(),this._Rect1_i(),this.btn_fangqi1_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_background_01_png";
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto.img_juzi0_i = function () {
		var t = new eui.Image();
		this.img_juzi0 = t;
		t.anchorOffsetX = 190;
		t.anchorOffsetY = 190;
		t.height = 380;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_picture_03_png";
		t.width = 380;
		t.x = 375;
		t.y = 550;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.7;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.btn_fangqi1_i = function () {
		var t = new eui.Button();
		this.btn_fangqi1 = t;
		t.label = "体验结束";
		t.x = 319.5;
		t.y = 545.79;
		return t;
	};
	_proto.img_shibai_i = function () {
		var t = new eui.Image();
		this.img_shibai = t;
		t.source = "mmm_youxi_Art-word_03_png";
		t.x = 334.5;
		t.y = 2.5;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/goodsItem.exml'] = window.goodsitem = (function (_super) {
	__extends(goodsitem, _super);
	function goodsitem() {
		_super.call(this);
		this.skinParts = ["goodsImg","goodsName","btn","btnText","price","group"];
		
		this.height = 318;
		this.width = 218;
		this.elementsContent = [this.group_i()];
	}
	var _proto = goodsitem.prototype;

	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 318;
		t.width = 218;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image1_i(),this.goodsImg_i(),this.goodsName_i(),this.btn_i(),this.btnText_i(),this.price_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 318;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_01_png";
		t.width = 218;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.goodsImg_i = function () {
		var t = new eui.Image();
		this.goodsImg = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillMode = "scale";
		t.height = 147;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "";
		t.verticalCenter = -57.5;
		t.width = 96;
		return t;
	};
	_proto.goodsName_i = function () {
		var t = new eui.Label();
		this.goodsName = t;
		t.scaleX = 0.9;
		t.scaleY = 1;
		t.size = 18;
		t.text = "啊实打实大苏打按说";
		t.textColor = 0x333333;
		t.width = 152;
		t.x = 26;
		t.y = 177.65;
		return t;
	};
	_proto.btn_i = function () {
		var t = new eui.Image();
		this.btn = t;
		t.name = "btn1";
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_button_04_png";
		t.x = 15;
		t.y = 253.97;
		return t;
	};
	_proto.btnText_i = function () {
		var t = new eui.Label();
		this.btnText = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "闯关挑战";
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.width = 112;
		t.y = 264.97;
		return t;
	};
	_proto.price_i = function () {
		var t = new eui.Label();
		this.price = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 18;
		t.text = "￥: 58.80";
		t.textColor = 0xEF0057;
		t.x = 19;
		t.y = 221.65;
		return t;
	};
	return goodsitem;
})(eui.Skin);generateEUI.paths['resource/skin/mainsence.exml'] = window.mainsence = (function (_super) {
	__extends(mainsence, _super);
	var mainsence$Skin6 = 	(function (_super) {
		__extends(mainsence$Skin6, _super);
		function mainsence$Skin6() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","mmm_dating_button_01_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainsence$Skin6.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "mmm_dating_button_01_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return mainsence$Skin6;
	})(eui.Skin);

	var mainsence$Skin7 = 	(function (_super) {
		__extends(mainsence$Skin7, _super);
		function mainsence$Skin7() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","mmm_dating_button_01_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = mainsence$Skin7.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "mmm_dating_button_01_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return mainsence$Skin7;
	})(eui.Skin);

	function mainsence() {
		_super.call(this);
		this.skinParts = ["lb_gold","img_chongzhi","lb_gold0","img_duihuan","lb_gold1","img_bg","rad1","rad2","rad3","top","lb_kh","lb_lp","lb_pf","rect_kh","rect_lp","rect_pf","daohang","lb_0","rect0","gp0","lb_100","rect100","gp100","lb_300","rect300","gp300","lb_500","rect500","gp500","leixing","gp_main"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Group6_i()];
	}
	var _proto = mainsence.prototype;

	_proto._Group6_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image1_i(),this.top_i(),this.daohang_i(),this._Image10_i(),this.leixing_i(),this.gp_main_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 1334;
		t.scale9Grid = new egret.Rectangle(10,10,60,60);
		t.source = "mmm_dating_Backplane_04_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.top_i = function () {
		var t = new eui.Group();
		this.top = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 323;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image2_i(),this._Group4_i(),this.img_bg_i(),this._Group5_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.height = 79;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Group1_i(),this._Group2_i(),this._Group3_i()];
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.height = 79;
		t.width = 250;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image3_i(),this.lb_gold_i(),this.img_chongzhi_i(),this._Image4_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.height = 34;
		t.scale9Grid = new egret.Rectangle(19,14,5,1);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_02_png";
		t.width = 172;
		t.x = 50.64;
		t.y = 17;
		return t;
	};
	_proto.lb_gold_i = function () {
		var t = new eui.Label();
		this.lb_gold = t;
		t.height = 34;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "999999";
		t.textColor = 0xffffff;
		t.verticalAlign = "middle";
		t.x = 82.34;
		t.y = 17;
		return t;
	};
	_proto.img_chongzhi_i = function () {
		var t = new eui.Button();
		this.img_chongzhi = t;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 190.67;
		t.y = 17;
		t.skinName = mainsence$Skin6;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_01_png";
		t.x = 41;
		t.y = 15;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.height = 79;
		t.width = 250;
		t.x = 250;
		t.y = 0;
		t.elementsContent = [this._Image5_i(),this.lb_gold0_i(),this._Image6_i(),this.img_duihuan_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.height = 34;
		t.scale9Grid = new egret.Rectangle(19,14,5,1);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_02_png";
		t.width = 172;
		t.x = 46.72;
		t.y = 17;
		return t;
	};
	_proto.lb_gold0_i = function () {
		var t = new eui.Label();
		this.lb_gold0 = t;
		t.height = 34;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "999999";
		t.textColor = 0xFFFFFF;
		t.verticalAlign = "middle";
		t.x = 85.06;
		t.y = 17;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_02_png";
		t.x = 45.98;
		t.y = 15;
		return t;
	};
	_proto.img_duihuan_i = function () {
		var t = new eui.Button();
		this.img_duihuan = t;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 188.95;
		t.y = 17;
		t.skinName = mainsence$Skin7;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.height = 79;
		t.width = 250;
		t.x = 500;
		t.y = 0;
		t.elementsContent = [this._Image7_i(),this.lb_gold1_i(),this._Image8_i()];
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.height = 34;
		t.scale9Grid = new egret.Rectangle(19,14,5,1);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_02_png";
		t.width = 172;
		t.x = 42.92;
		t.y = 17;
		return t;
	};
	_proto.lb_gold1_i = function () {
		var t = new eui.Label();
		this.lb_gold1 = t;
		t.height = 34;
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 24;
		t.text = "999999";
		t.textColor = 0xFFFFFF;
		t.verticalAlign = "middle";
		t.x = 109.93;
		t.y = 17;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_icon_03_png";
		t.x = 36.52;
		t.y = 15;
		return t;
	};
	_proto.img_bg_i = function () {
		var t = new eui.Image();
		this.img_bg = t;
		t.anchorOffsetY = 0;
		t.height = 244;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "lunbo_1_png";
		t.width = 750;
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto._Group5_i = function () {
		var t = new eui.Group();
		t.height = 24;
		t.width = 50;
		t.x = 350;
		t.y = 277;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this.rad1_i(),this.rad2_i(),this.rad3_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		t.horizontalAlign = "center";
		t.verticalAlign = "justify";
		return t;
	};
	_proto.rad1_i = function () {
		var t = new eui.RadioButton();
		this.rad1 = t;
		t.height = 22;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.selected = true;
		t.width = 22;
		t.x = 334;
		t.y = 45.73000000000002;
		return t;
	};
	_proto.rad2_i = function () {
		var t = new eui.RadioButton();
		this.rad2 = t;
		t.height = 22;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 22;
		t.x = 364;
		t.y = 45.73000000000002;
		return t;
	};
	_proto.rad3_i = function () {
		var t = new eui.RadioButton();
		this.rad3 = t;
		t.height = 22;
		t.label = "";
		t.scaleX = 1;
		t.scaleY = 1;
		t.visible = false;
		t.width = 22;
		t.x = 394;
		t.y = 45.73000000000002;
		return t;
	};
	_proto.daohang_i = function () {
		var t = new eui.Group();
		this.daohang = t;
		t.anchorOffsetY = 0;
		t.height = 56;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 327;
		t.elementsContent = [this._Image9_i(),this.lb_kh_i(),this.lb_lp_i(),this.lb_pf_i(),this.rect_kh_i(),this.rect_lp_i(),this.rect_pf_i()];
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.scale9Grid = new egret.Rectangle(7,7,42,42);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_03_png";
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.lb_kh_i = function () {
		var t = new eui.Label();
		this.lb_kh = t;
		t.name = "btn_kh";
		t.size = 28;
		t.text = "口红";
		t.x = 56;
		t.y = 13;
		return t;
	};
	_proto.lb_lp_i = function () {
		var t = new eui.Label();
		this.lb_lp = t;
		t.name = "btn_lp";
		t.size = 28;
		t.text = "礼品";
		t.x = 206;
		t.y = 13;
		return t;
	};
	_proto.lb_pf_i = function () {
		var t = new eui.Label();
		this.lb_pf = t;
		t.name = "btn_pf";
		t.size = 28;
		t.text = "皮肤";
		t.x = 352.06;
		t.y = 14.34;
		return t;
	};
	_proto.rect_kh_i = function () {
		var t = new eui.Rect();
		this.rect_kh = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 58;
		t.name = "rect_kh";
		t.width = 98;
		t.x = 34;
		t.y = 0;
		return t;
	};
	_proto.rect_lp_i = function () {
		var t = new eui.Rect();
		this.rect_lp = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 58;
		t.name = "rect_lp";
		t.width = 98;
		t.x = 187;
		t.y = 0;
		return t;
	};
	_proto.rect_pf_i = function () {
		var t = new eui.Rect();
		this.rect_pf = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 58;
		t.name = "rect_pf";
		t.width = 98;
		t.x = 329;
		t.y = -2;
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.anchorOffsetX = 0;
		t.scale9Grid = new egret.Rectangle(7,7,44,44);
		t.source = "mmm_dating_Backplane_05_png";
		t.width = 750;
		t.x = 0;
		t.y = 387;
		return t;
	};
	_proto.leixing_i = function () {
		var t = new eui.Group();
		this.leixing = t;
		t.height = 58;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 387;
		t.layout = this._HorizontalLayout2_i();
		t.elementsContent = [this.gp0_i(),this.gp100_i(),this.gp300_i(),this.gp500_i()];
		return t;
	};
	_proto._HorizontalLayout2_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 0;
		t.horizontalAlign = "left";
		t.paddingLeft = 0;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.gp0_i = function () {
		var t = new eui.Group();
		this.gp0 = t;
		t.anchorOffsetY = 0;
		t.height = 58;
		t.width = 187.5;
		t.x = 45;
		t.y = 0;
		t.elementsContent = [this.lb_0_i(),this.rect0_i()];
		return t;
	};
	_proto.lb_0_i = function () {
		var t = new eui.Label();
		this.lb_0 = t;
		t.horizontalCenter = 0;
		t.name = "btn_0";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "免费区";
		t.textColor = 0x333333;
		t.y = 14;
		return t;
	};
	_proto.rect0_i = function () {
		var t = new eui.Rect();
		this.rect0 = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 58;
		t.horizontalCenter = 0;
		t.name = "rect0";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 98;
		t.y = 0;
		return t;
	};
	_proto.gp100_i = function () {
		var t = new eui.Group();
		this.gp100 = t;
		t.height = 58;
		t.width = 187.5;
		t.x = 206;
		t.y = 0;
		t.elementsContent = [this.lb_100_i(),this.rect100_i()];
		return t;
	};
	_proto.lb_100_i = function () {
		var t = new eui.Label();
		this.lb_100 = t;
		t.horizontalCenter = 0;
		t.name = "btn_100";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "100金币区";
		t.textColor = 0x333333;
		t.y = 14;
		return t;
	};
	_proto.rect100_i = function () {
		var t = new eui.Rect();
		this.rect100 = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 58;
		t.horizontalCenter = 0;
		t.name = "rect100";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 127.34;
		t.y = 0;
		return t;
	};
	_proto.gp300_i = function () {
		var t = new eui.Group();
		this.gp300 = t;
		t.height = 58;
		t.width = 187.5;
		t.x = 374;
		t.y = 0;
		t.elementsContent = [this.lb_300_i(),this.rect300_i()];
		return t;
	};
	_proto.lb_300_i = function () {
		var t = new eui.Label();
		this.lb_300 = t;
		t.horizontalCenter = 0;
		t.name = "btn_300";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "300金币区";
		t.textColor = 0x333333;
		t.y = 14;
		return t;
	};
	_proto.rect300_i = function () {
		var t = new eui.Rect();
		this.rect300 = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 58;
		t.horizontalCenter = 0;
		t.name = "rect300";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 122;
		t.y = 0;
		return t;
	};
	_proto.gp500_i = function () {
		var t = new eui.Group();
		this.gp500 = t;
		t.height = 58;
		t.width = 187.5;
		t.x = 574;
		t.y = 0;
		t.elementsContent = [this.lb_500_i(),this.rect500_i()];
		return t;
	};
	_proto.lb_500_i = function () {
		var t = new eui.Label();
		this.lb_500 = t;
		t.horizontalCenter = 0;
		t.name = "btn_500";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 26;
		t.text = "500金币区";
		t.textColor = 0x333333;
		t.y = 14;
		return t;
	};
	_proto.rect500_i = function () {
		var t = new eui.Rect();
		this.rect500 = t;
		t.anchorOffsetX = 0;
		t.fillAlpha = 0;
		t.height = 58;
		t.horizontalCenter = 0;
		t.name = "rect500";
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 122;
		t.y = 0;
		return t;
	};
	_proto.gp_main_i = function () {
		var t = new eui.Group();
		this.gp_main = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 366;
		t.width = 750;
		t.x = 0;
		t.y = 445;
		t.layout = this._HorizontalLayout3_i();
		return t;
	};
	_proto._HorizontalLayout3_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 24;
		t.horizontalAlign = "left";
		t.paddingLeft = 24;
		t.paddingTop = 0;
		t.verticalAlign = "middle";
		return t;
	};
	return mainsence;
})(eui.Skin);generateEUI.paths['resource/skin/overSuccess.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	var goods_item$Skin8 = 	(function (_super) {
		__extends(goods_item$Skin8, _super);
		function goods_item$Skin8() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = goods_item$Skin8.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_05_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return goods_item$Skin8;
	})(eui.Skin);

	var goods_item$Skin9 = 	(function (_super) {
		__extends(goods_item$Skin9, _super);
		function goods_item$Skin9() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = goods_item$Skin9.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_04_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return goods_item$Skin9;
	})(eui.Skin);

	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_juzi","lb_score","lb_score0","btn_share","btn_reset","img_juzi0","btn_fangqi1","gp_tiyan"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this.img_juzi_i(),this._Image2_i(),this.lb_score_i(),this.lb_score0_i(),this.btn_share_i(),this.btn_reset_i(),this.gp_tiyan_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "mmm_youxi_background_01_png";
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto.img_juzi_i = function () {
		var t = new eui.Image();
		this.img_juzi = t;
		t.anchorOffsetX = 190;
		t.anchorOffsetY = 190;
		t.height = 380;
		t.source = "mmm_youxi_picture_03_png";
		t.width = 380;
		t.x = 375;
		t.y = 550;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.lb_score_i = function () {
		var t = new eui.Label();
		this.lb_score = t;
		t.text = "好厉害！恭喜你获得奖品";
		t.textColor = 0x000000;
		t.x = 215;
		t.y = 132.55;
		return t;
	};
	_proto.lb_score0_i = function () {
		var t = new eui.Label();
		this.lb_score0 = t;
		t.text = "口红3号";
		t.textColor = 0x000000;
		t.x = 321;
		t.y = 233.46;
		return t;
	};
	_proto.btn_share_i = function () {
		var t = new eui.Button();
		this.btn_share = t;
		t.label = "分享";
		t.x = 50;
		t.y = 1014.79;
		t.skinName = goods_item$Skin8;
		return t;
	};
	_proto.btn_reset_i = function () {
		var t = new eui.Button();
		this.btn_reset = t;
		t.height = 72;
		t.label = "再玩一次";
		t.width = 216;
		t.x = 483;
		t.y = 1014.79;
		t.skinName = goods_item$Skin9;
		return t;
	};
	_proto.gp_tiyan_i = function () {
		var t = new eui.Group();
		this.gp_tiyan = t;
		t.height = 1334;
		t.visible = false;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image3_i(),this.img_juzi0_i(),this._Image4_i(),this._Rect1_i(),this.btn_fangqi1_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_background_01_png";
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto.img_juzi0_i = function () {
		var t = new eui.Image();
		this.img_juzi0 = t;
		t.anchorOffsetX = 190;
		t.anchorOffsetY = 190;
		t.height = 380;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_picture_03_png";
		t.width = 380;
		t.x = 375;
		t.y = 550;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.7;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.btn_fangqi1_i = function () {
		var t = new eui.Button();
		this.btn_fangqi1 = t;
		t.label = "体验结束";
		t.x = 319.5;
		t.y = 545.79;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/paihang_items.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	function goods_item() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 136;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this._Image2_i(),this._Image3_i(),this._Label1_i(),this._Label2_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 130;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 750;
		t.x = 0;
		t.y = 3;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.height = 100;
		t.source = "mmm_dating_picture_02_png";
		t.width = 100;
		t.x = 230;
		t.y = 18;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.height = 100;
		t.source = "mmm_dating_picture_02_png";
		t.width = 100;
		t.x = 87;
		t.y = 22;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.size = 28;
		t.text = "阿达达";
		t.textColor = 0x333333;
		t.x = 405;
		t.y = 58;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.size = 28;
		t.text = "232";
		t.textColor = 0x333333;
		t.x = 612;
		t.y = 58;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/shouchong.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_close"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Image2_i(),this._Image3_i(),this.img_close_i(),this._Label1_i(),this._Image4_i(),this._Label2_i(),this._Label3_i(),this._Image5_i(),this._Image6_i(),this._Image7_i(),this._Image8_i(),this._Label4_i(),this._Label5_i(),this._Label6_i(),this._Label7_i(),this._Image9_i(),this._Label8_i(),this._Image10_i(),this._Label9_i(),this._Image11_i(),this._Label10_i(),this._Image12_i(),this._Label11_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 642;
		t.scale9Grid = new egret.Rectangle(15,15,96,96);
		t.source = "mmm_dating_Backplane_07_png";
		t.width = 676;
		t.x = 37;
		t.y = 346;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_header_01_png";
		t.x = 148.5;
		t.y = 283.5;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_Art-word_02_png";
		t.x = 266.5;
		t.y = 297;
		return t;
	};
	_proto.img_close_i = function () {
		var t = new eui.Image();
		this.img_close = t;
		t.source = "mmm_dating_button_02_03_png";
		t.x = 344;
		t.y = 1020;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.size = 50;
		t.text = "充值界面";
		t.textColor = 0x140404;
		t.x = 275;
		t.y = 642;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.height = 500;
		t.scale9Grid = new egret.Rectangle(38,25,9,7);
		t.source = "mmm_dating_Backplane_08_png";
		t.width = 636;
		t.x = 57;
		t.y = 425;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.size = 22;
		t.text = "多冲多得，机会难得";
		t.textColor = 0x333333;
		t.x = 275;
		t.y = 391.5;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.size = 20;
		t.text = "注释：同档位活动只能参加一次  活动截止至 2018年11月30日";
		t.textColor = 0x666666;
		t.x = 102.5;
		t.y = 952.85;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.height = 118;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 624;
		t.x = 62;
		t.y = 430;
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.height = 118;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 624;
		t.x = 62;
		t.y = 554.3333333333333;
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.height = 118;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 624;
		t.x = 62;
		t.y = 677.6666666666665;
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.height = 118;
		t.scale9Grid = new egret.Rectangle(39,39,51,46);
		t.source = "mmm_dating_Backplane_06_png";
		t.width = 624;
		t.x = 62;
		t.y = 802;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "首充20元额外获得胡了三国卡牌推广版+50金币";
		t.textColor = 0x333333;
		t.x = 87;
		t.y = 450;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "首充100元额外获得价值50元的胡了三国卡牌铁盒版+100金币";
		t.textColor = 0x333333;
		t.width = 542;
		t.x = 87;
		t.y = 574;
		return t;
	};
	_proto._Label6_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "首充200元额外获得价值119元的欧莱雅润唇膏619秋叶一支+300金币";
		t.textColor = 0x333333;
		t.width = 542;
		t.x = 87;
		t.y = 697;
		return t;
	};
	_proto._Label7_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "首充300元额外获得价值249元的兰蔻精密眼线液一瓶+500金币";
		t.textColor = 0x333333;
		t.width = 542;
		t.x = 87;
		t.y = 822;
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 493;
		t.y = 489;
		return t;
	};
	_proto._Label8_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "领取";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.x = 540;
		t.y = 502.5;
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 493;
		t.y = 609.66;
		return t;
	};
	_proto._Label9_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "领取";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 540;
		t.y = 623.16;
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 493;
		t.y = 738.33;
		return t;
	};
	_proto._Label10_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "领取";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 540;
		t.y = 751.83;
		return t;
	};
	_proto._Image12_i = function () {
		var t = new eui.Image();
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 493;
		t.y = 860.33;
		return t;
	};
	_proto._Label11_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "领取";
		t.textColor = 0xFFFFFF;
		t.touchEnabled = false;
		t.x = 540;
		t.y = 873.83;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/tishi.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_close","edu","btnQueding","group","edu0"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Image2_i(),this.img_close_i(),this.group_i(),this.edu0_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 414;
		t.scale9Grid = new egret.Rectangle(15,15,96,96);
		t.source = "mmm_dating_Backplane_07_png";
		t.width = 676;
		t.x = 37;
		t.y = 346;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_header_01_png";
		t.x = 148.5;
		t.y = 283.5;
		return t;
	};
	_proto.img_close_i = function () {
		var t = new eui.Image();
		this.img_close = t;
		t.source = "mmm_dating_button_02_03_png";
		t.visible = false;
		t.x = 344;
		t.y = 1020;
		return t;
	};
	_proto.group_i = function () {
		var t = new eui.Group();
		this.group = t;
		t.height = 414;
		t.width = 676;
		t.x = 37;
		t.y = 346;
		t.elementsContent = [this.edu_i(),this.btnQueding_i(),this._Label1_i()];
		return t;
	};
	_proto.edu_i = function () {
		var t = new eui.Label();
		this.edu = t;
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "金币不足，请充值";
		t.textColor = 0x333333;
		t.touchEnabled = false;
		t.x = 222;
		t.y = 127;
		return t;
	};
	_proto.btnQueding_i = function () {
		var t = new eui.Image();
		this.btnQueding = t;
		t.source = "mmm_dating_button_03_png";
		t.x = 230;
		t.y = 266;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "确定";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.x = 310;
		t.y = 287;
		return t;
	};
	_proto.edu0_i = function () {
		var t = new eui.Label();
		this.edu0 = t;
		t.fontFamily = "SimHei";
		t.scaleX = 1;
		t.scaleY = 1;
		t.size = 28;
		t.text = "提示";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.x = 347;
		t.y = 303;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/xsover.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	var goods_item$Skin10 = 	(function (_super) {
		__extends(goods_item$Skin10, _super);
		function goods_item$Skin10() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = goods_item$Skin10.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_05_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return goods_item$Skin10;
	})(eui.Skin);

	var goods_item$Skin11 = 	(function (_super) {
		__extends(goods_item$Skin11, _super);
		function goods_item$Skin11() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = goods_item$Skin11.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "mmm_dating_button_04_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return goods_item$Skin11;
	})(eui.Skin);

	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_juzi","lb_score","btn_fangqi","btn_reset","img_juzi0","btn_fangqi1","gp_tiyan"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this.img_juzi_i(),this._Image2_i(),this.lb_score_i(),this._Label1_i(),this._Label2_i(),this.btn_fangqi_i(),this.btn_reset_i(),this.gp_tiyan_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "mmm_youxi_background_01_png";
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto.img_juzi_i = function () {
		var t = new eui.Image();
		this.img_juzi = t;
		t.anchorOffsetX = 190;
		t.anchorOffsetY = 190;
		t.height = 380;
		t.source = "mmm_youxi_picture_03_png";
		t.width = 380;
		t.x = 375;
		t.y = 550;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.lb_score_i = function () {
		var t = new eui.Label();
		this.lb_score = t;
		t.text = "游戏结束！恭喜您获得了100分";
		t.textColor = 0x000000;
		t.x = 169.5;
		t.y = 124.55;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.text = "排行榜第一可以获得以下奖励哟";
		t.textColor = 0x000000;
		t.x = 167.5;
		t.y = 180.55;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.text = "距开奖时间还有   01 : 15 : 33";
		t.textColor = 0x000000;
		t.x = 169.5;
		t.y = 244.55;
		return t;
	};
	_proto.btn_fangqi_i = function () {
		var t = new eui.Button();
		this.btn_fangqi = t;
		t.height = 72;
		t.label = "放弃重玩";
		t.width = 216;
		t.x = 61.5;
		t.y = 1014.79;
		t.skinName = goods_item$Skin10;
		return t;
	};
	_proto.btn_reset_i = function () {
		var t = new eui.Button();
		this.btn_reset = t;
		t.height = 72;
		t.label = "金币继续";
		t.width = 216;
		t.x = 479.5;
		t.y = 1014.79;
		t.skinName = goods_item$Skin11;
		return t;
	};
	_proto.gp_tiyan_i = function () {
		var t = new eui.Group();
		this.gp_tiyan = t;
		t.height = 1334;
		t.visible = false;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this._Image3_i(),this.img_juzi0_i(),this._Image4_i(),this._Rect1_i(),this.btn_fangqi1_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_background_01_png";
		t.x = 0;
		t.y = 79;
		return t;
	};
	_proto.img_juzi0_i = function () {
		var t = new eui.Image();
		this.img_juzi0 = t;
		t.anchorOffsetX = 190;
		t.anchorOffsetY = 190;
		t.height = 380;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_youxi_picture_03_png";
		t.width = 380;
		t.x = 375;
		t.y = 550;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "mmm_dating_picture_04_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.7;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.scaleX = 1;
		t.scaleY = 1;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.btn_fangqi1_i = function () {
		var t = new eui.Button();
		this.btn_fangqi1 = t;
		t.label = "体验结束";
		t.x = 319.5;
		t.y = 545.79;
		return t;
	};
	return goods_item;
})(eui.Skin);generateEUI.paths['resource/skin/yaoqing.exml'] = window.goods_item = (function (_super) {
	__extends(goods_item, _super);
	function goods_item() {
		_super.call(this);
		this.skinParts = ["img_close"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Rect1_i(),this._Image1_i(),this._Label1_i(),this._Label2_i(),this._Image2_i(),this._Image3_i(),this.img_close_i(),this._Image4_i(),this._Label3_i(),this._Image5_i(),this._Label4_i()];
	}
	var _proto = goods_item.prototype;

	_proto._Rect1_i = function () {
		var t = new eui.Rect();
		t.fillAlpha = 0.3;
		t.fillColor = 0x000000;
		t.height = 1334;
		t.width = 750;
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.height = 600;
		t.scale9Grid = new egret.Rectangle(15,15,96,96);
		t.source = "mmm_dating_Backplane_01_png";
		t.width = 600;
		t.x = 75;
		t.y = 367;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "邀请10位好友一起游戏，可以获得价值99元的毛绒玩具一个";
		t.textColor = 0x140404;
		t.width = 550;
		t.x = 100;
		t.y = 469;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "已邀请人数：（10）";
		t.textAlign = "center";
		t.textColor = 0x140404;
		t.verticalAlign = "middle";
		t.width = 550;
		t.x = 100;
		t.y = 745;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_header_02_png";
		t.x = 148.5;
		t.y = 307.5;
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.source = "mmm_dating_Art-word_03_png";
		t.x = 266;
		t.y = 322;
		return t;
	};
	_proto.img_close_i = function () {
		var t = new eui.Image();
		this.img_close = t;
		t.source = "mmm_dating_button_02_03_png";
		t.x = 344;
		t.y = 1005.79;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_03_png";
		t.x = 143;
		t.y = 843;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "领取奖品";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.x = 166.6;
		t.y = 854.5;
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.scaleX = 0.7;
		t.scaleY = 0.7;
		t.source = "mmm_dating_button_05_png";
		t.x = 449.3;
		t.y = 843;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.size = 26;
		t.text = "分享链接";
		t.textColor = 0xffffff;
		t.touchEnabled = false;
		t.x = 472.9;
		t.y = 854.5;
		return t;
	};
	return goods_item;
})(eui.Skin);