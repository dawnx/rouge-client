module Data {
	export class GameContext {

		public static player:PlayerData;
		// 排行榜数据；
		public static rankDataArray:RankData[];

		public constructor() {
		}
	}
}