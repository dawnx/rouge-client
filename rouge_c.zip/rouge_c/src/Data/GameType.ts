module Data {
	export class GameType {


		//public gameType: number; // 1 体验 ，2 闯关，  3 竞速
        public static TI_YAN:number = 1;
        public static CHUANG_GUAN:number = 2;
        public static JING_SU:number = 3;

	}
}