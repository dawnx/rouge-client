module Data {
	export class GoodsType {
		//1口红，2礼品，3皮肤
		public static KOU_HONG: number = 1;
		public static LI_PIN: number = 2;
		public static PI_FU: number = 3;

	}
}