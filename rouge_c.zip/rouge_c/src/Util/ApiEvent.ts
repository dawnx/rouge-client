class ApiEvent {

	public static PLAYER_INFO = "player_info";

 

}
