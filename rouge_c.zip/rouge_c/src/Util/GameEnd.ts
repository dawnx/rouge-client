// TypeScript file
class GameEnd{
    public static readonly RESULT_WIN:number = 1;
    public static readonly RESULT_LOSE:number = 0;
    public static readonly RESULT_RESET:number = 1;

}