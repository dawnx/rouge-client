// TypeScript file
class ItemDefine{
    public static readonly Diamond:number = 10001;
    public static readonly Gold:number = 10002;
    public static readonly LuckyCoin:number = 10003;

}